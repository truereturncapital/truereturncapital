require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const path = require('path');

const { attachUser } = require('./auth');
const customerRoutes = require('./routes/customer');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('trust proxy', 1);
app.use(express.json({ limit: '256kb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(attachUser);

// Slow down credential guessing without getting in a real customer's way.
app.use(
  '/api/auth/login',
  rateLimit({ windowMs: 15 * 60 * 1000, max: 20, message: { error: 'Too many attempts. Try again in a few minutes.' } })
);
app.use(
  '/api/auth/signup',
  rateLimit({ windowMs: 60 * 60 * 1000, max: 10, message: { error: 'Too many sign-ups from this device. Try again later.' } })
);

app.use('/api', customerRoutes);
app.use('/api/admin', adminRoutes);

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.get('/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'No such endpoint.' });
  res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});

app.use((err, req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Something broke on our side. Try again.' });
});

app.listen(PORT, () => {
  console.log(`\n  TrueReturn Gold running → http://localhost:${PORT}`);
  console.log(`  Admin panel             → http://localhost:${PORT}/admin\n`);
});
