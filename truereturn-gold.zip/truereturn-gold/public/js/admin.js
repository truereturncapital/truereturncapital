let PLANS = [];
let ME = null;
let reqStatus = 'pending';
let invStatus = 'all';
let editingPlanId = null;

/* ---------------- boot ---------------- */
async function boot() {
  try {
    const { user } = await api('/api/auth/me');
    if (user.role !== 'admin') { location.href = '/dashboard'; return; }
    ME = user;
  } catch { location.href = '/login'; return; }

  document.getElementById('whoName').textContent = ME.name;
  await loadPlans();
  setupDeclare();
  await Promise.all([loadHome(), loadRequests()]);
}

async function loadPlans() {
  const { plans } = await api('/api/admin/plans');
  PLANS = plans;
}

/* ---------------- tabs ---------------- */
const loaders = {
  home: loadHome,
  requests: loadRequests,
  customers: loadCustomers,
  books: loadInvestments,
  plans: loadPlanTable,
  rates: loadRates,
  settings: loadSettings,
  declare: setupDeclare,
};

function switchTab(name) {
  document.querySelectorAll('.tab').forEach((t) =>
    t.setAttribute('aria-selected', String(t.dataset.panel === name)));
  document.querySelectorAll('.panel').forEach((p) => (p.hidden = p.id !== 'panel-' + name));
  window.scrollTo({ top: 0, behavior: 'smooth' });
  loaders[name]?.();
}
document.querySelectorAll('.tab').forEach((t) =>
  t.addEventListener('click', () => switchTab(t.dataset.panel)));

/* ---------------- overview ---------------- */
async function loadHome() {
  const d = await api('/api/admin/stats');
  const s = d.stats;

  document.getElementById('homeSub').textContent =
    `${MONTHS[d.month.month]} ${d.month.year} · ${s.active_books} open book${s.active_books === 1 ? '' : 's'}`;

  document.getElementById('homeStats').innerHTML = `
    <div class="stat">
      <div class="stat__k">Customers</div><div class="stat__v">${s.customers}</div>
      <div class="stat__n">${s.customers_30d} joined in 30 days</div>
    </div>
    <div class="stat">
      <div class="stat__k">Amount held</div><div class="stat__v">${inrShort(s.principal)}</div>
      <div class="stat__n">${s.active_books} open books</div>
    </div>
    <div class="stat stat--gold">
      <div class="stat__k">Credited to date</div><div class="stat__v">${inrShort(s.returned)}</div>
      <div class="stat__n">All declared months</div>
    </div>
    <div class="stat">
      <div class="stat__k">Waiting on you</div>
      <div class="stat__v" style="${s.pending_requests ? 'color:var(--kumkum)' : ''}">${s.pending_requests}</div>
      <div class="stat__n">${s.pending_requests ? 'Requests to confirm' : 'Nothing pending'}</div>
    </div>`;

  document.getElementById('homePlans').innerHTML = d.byPlan.map((p) => `
    <tr>
      <td><strong>${esc(p.name)}</strong><br><span class="mono" style="font-size:.72rem;opacity:.6">${inrShort(p.min_amount)}–${inrShort(p.max_amount)}</span></td>
      <td class="right mono">${p.books}</td>
      <td class="right mono">${inrShort(p.principal)}</td>
      <td class="right">${p.current_rate === null
        ? '<span class="chip chip--pending">not set</span>'
        : `<span class="pb__rate">${pct(p.current_rate)}</span>`}</td>
      <td class="right mono">${p.this_month_cost === null ? '—' : inr(p.this_month_cost)}</td>
    </tr>`).join('');

  const names = { purchase: 'New book', topup: 'Top-up', upgrade: 'Upgrade', return: 'Credit' };
  document.getElementById('homeRecent').innerHTML = d.recent.length
    ? d.recent.map((r) => `
        <tr>
          <td style="width:100%">
            <strong>${esc(r.name)}</strong><br>
            <span style="font-size:.78rem;opacity:.65">${names[r.type] || r.type} · ${inr(r.amount)} · ${dateStr(r.created_at)}</span>
          </td>
          <td class="right">${chipFor(r.status)}</td>
        </tr>`).join('')
    : `<tr><td><div class="empty" style="padding:2rem 0"><strong>Nothing yet</strong>Activity will show here.</div></td></tr>`;

  setBadge(s.pending_requests);
}

function setBadge(n) {
  const b = document.getElementById('reqBadge');
  b.hidden = !n;
  b.textContent = n;
}

/* ---------------- declare the month ---------------- */
function setupDeclare() {
  const mSel = document.getElementById('declMonth');
  const ySel = document.getElementById('declYear');
  const now = new Date();

  if (!mSel.options.length) {
    mSel.innerHTML = MONTHS.slice(1).map((m, i) => `<option value="${i + 1}">${m}</option>`).join('');
    const y = now.getFullYear();
    ySel.innerHTML = [y - 2, y - 1, y, y + 1].map((v) => `<option value="${v}">${v}</option>`).join('');
    mSel.value = now.getMonth() + 1;
    ySel.value = y;
    mSel.addEventListener('change', paintDeclareRows);
    ySel.addEventListener('change', paintDeclareRows);
  }
  paintDeclareRows();
}

async function paintDeclareRows() {
  const month = Number(document.getElementById('declMonth').value);
  const year = Number(document.getElementById('declYear').value);
  document.getElementById('declMonthLabel').textContent = `${MONTHS[month]} ${year}`;

  const { rates } = await api('/api/admin/rates');
  const existing = new Map(rates.filter((r) => r.year === year && r.month === month).map((r) => [r.plan_id, r]));

  document.getElementById('declRows').innerHTML = PLANS.filter((p) => p.is_active).map((p) => {
    const prior = existing.get(p.id);
    return `
    <div class="declare-row">
      <div>
        <div class="declare-row__name">${esc(p.name)}</div>
        <div class="declare-row__meta">
          ${p.active_books} open · ${inrShort(p.principal)} held
          ${prior ? ` · already declared at ${pct(prior.rate)}` : ''}
        </div>
      </div>
      <input class="input input--num" type="number" step="0.01" min="0" max="100"
             id="rate_${p.id}" value="${prior ? prior.rate : ''}"
             placeholder="${p.indicative_rate}" aria-label="Rate for ${esc(p.name)}">
      <div class="declare-row__cost" id="cost_${p.id}">—</div>
    </div>`;
  }).join('') || '<div class="empty"><strong>No active plans</strong>Add a plan first.</div>';

  PLANS.filter((p) => p.is_active).forEach((p) => {
    const input = document.getElementById(`rate_${p.id}`);
    const paint = () => {
      const r = Number(input.value);
      document.getElementById(`cost_${p.id}`).textContent =
        Number.isFinite(r) && input.value !== '' ? `costs ${inr((p.principal * r) / 100)}` : '—';
    };
    input.addEventListener('input', paint);
    paint();
  });
}

function collectRates() {
  return PLANS.filter((p) => p.is_active)
    .map((p) => ({ plan_id: p.id, rate: document.getElementById(`rate_${p.id}`)?.value }))
    .filter((e) => e.rate !== '' && e.rate !== undefined && e.rate !== null)
    .map((e) => ({ ...e, rate: Number(e.rate) }));
}

document.getElementById('declPreview').addEventListener('click', async (e) => {
  showError('declErr', '');
  const entries = collectRates();
  if (!entries.length) return showError('declErr', 'Enter a rate for at least one book.');

  const year = Number(document.getElementById('declYear').value);
  const month = Number(document.getElementById('declMonth').value);

  await withBusy(e.target, 'Working it out…', async () => {
    const results = [];
    for (const en of entries) {
      const r = await api('/api/admin/rates/preview', { method: 'POST', body: { ...en, year, month } });
      results.push({ ...r, plan: PLANS.find((p) => p.id === en.plan_id), rate: en.rate });
    }
    const grand = results.reduce((a, r) => a + r.total_payout, 0);
    const books = results.reduce((a, r) => a + r.books, 0);

    document.getElementById('declCost').innerHTML = `
      <div class="stat stat--gold" style="margin-bottom:1rem">
        <div class="stat__k">Total to credit</div>
        <div class="stat__v">${inr(grand)}</div>
        <div class="stat__n">${books} book${books === 1 ? '' : 's'} across ${results.length} plan${results.length === 1 ? '' : 's'}</div>
      </div>
      <table class="data">
        <thead><tr><th>Book</th><th class="right">Rate</th><th class="right">Books</th><th class="right">Credit</th></tr></thead>
        <tbody>${results.map((r) => `
          <tr>
            <td>${esc(r.plan.name)}${r.already_declared !== null ? '<br><span style="font-size:.7rem;color:var(--kumkum)">replaces ' + pct(r.already_declared) + '</span>' : ''}</td>
            <td class="right mono">${pct(r.rate)}</td>
            <td class="right mono">${r.books}</td>
            <td class="right mono">${inr(r.total_payout)}</td>
          </tr>`).join('')}</tbody>
      </table>
      <p style="margin:1rem 0 0;font-size:.78rem;color:rgba(12,31,25,.6)">
        Nothing has been posted yet. Select "Post these rates" to commit.
      </p>`;
  });
});

document.getElementById('declPost').addEventListener('click', async (e) => {
  showError('declErr', '');
  const entries = collectRates();
  if (!entries.length) return showError('declErr', 'Enter a rate for at least one book.');

  const year = Number(document.getElementById('declYear').value);
  const month = Number(document.getElementById('declMonth').value);
  const note = document.getElementById('declNote').value;

  const lines = entries.map((en) => `${PLANS.find((p) => p.id === en.plan_id).name}: ${en.rate}%`).join('\n');
  if (!confirm(`Post these rates for ${MONTHS[month]} ${year}?\n\n${lines}\n\nThis credits every open book and updates the public board.`)) return;

  await withBusy(e.target, 'Posting…', async () => {
    try {
      const out = await api('/api/admin/rates/declare-bulk', {
        method: 'POST',
        body: { year, month, entries: entries.map((en) => ({ ...en, note })) },
      });
      const total = out.results.reduce((a, r) => a + r.total, 0);
      const books = out.results.reduce((a, r) => a + r.books, 0);
      toast(`Posted. ${inr(total)} credited across ${books} book${books === 1 ? '' : 's'}.`);
      await loadPlans();
      await paintDeclareRows();
      document.getElementById('declCost').innerHTML = `
        <div class="notice notice--ok" style="margin:0">
          Posted for ${MONTHS[month]} ${year}. It is live on the board and in every passbook.
        </div>`;
    } catch (err) { showError('declErr', err.message); }
  });
});

/* ---------------- requests ---------------- */
document.getElementById('reqFilter').addEventListener('click', (e) => {
  if (e.target.tagName !== 'BUTTON') return;
  reqStatus = e.target.dataset.s;
  document.querySelectorAll('#reqFilter button').forEach((b) =>
    b.setAttribute('aria-pressed', String(b.dataset.s === reqStatus)));
  loadRequests();
});

async function loadRequests() {
  const { requests } = await api(`/api/admin/requests?status=${reqStatus}`);
  const names = { purchase: 'New book', topup: 'Top-up', upgrade: 'Upgrade' };

  if (reqStatus === 'pending') setBadge(requests.length);

  document.getElementById('reqBody').innerHTML = requests.length
    ? requests.map((r) => {
        let detail = r.meta || '';
        if (r.type === 'upgrade') {
          try { const m = JSON.parse(r.meta || '{}'); detail = m.to_plan ? `→ ${m.to_plan}, new total ${inr(m.new_total)}` : detail; }
          catch { /* plain text */ }
        }
        return `
        <tr>
          <td class="mono" style="white-space:nowrap;font-size:.78rem">${dateStr(r.created_at)}</td>
          <td><strong>${esc(r.name)}</strong><br><span style="font-size:.75rem;opacity:.65">${esc(r.phone)}</span></td>
          <td>${names[r.type] || r.type}</td>
          <td><span class="mono" style="font-size:.75rem">${esc(r.ref_no || '—')}</span><br><span style="font-size:.75rem;opacity:.65">${esc(r.plan_name || '')}</span></td>
          <td class="right mono">${inr(r.amount)}</td>
          <td style="font-size:.78rem;max-width:200px">${esc(detail)}</td>
          <td class="right" style="white-space:nowrap">
            ${r.status === 'pending' ? `
              <button class="btn btn--gold btn--sm" onclick="approveReq(${r.id})">Confirm payment</button>
              <button class="btn btn--danger btn--sm" onclick="rejectReq(${r.id})">Reject</button>` : chipFor(r.status)}
          </td>
        </tr>`;
      }).join('')
    : `<tr><td colspan="7"><div class="empty"><strong>Nothing ${reqStatus}</strong>${reqStatus === 'pending' ? 'Every request has been dealt with.' : 'No records in this state.'}</div></td></tr>`;
}

async function approveReq(id) {
  const date = prompt('Opening date for this book (YYYY-MM-DD). Leave as-is for today.',
    new Date().toISOString().slice(0, 10));
  if (date === null) return;
  try {
    await api(`/api/admin/requests/${id}/approve`, { method: 'POST', body: { start_date: date } });
    toast('Payment confirmed. The book is open.');
    loadRequests(); loadHome(); loadPlans();
  } catch (e) { toast(e.message, true); }
}

async function rejectReq(id) {
  const reason = prompt('Why is this being rejected? The customer sees this.', 'Payment not received');
  if (reason === null) return;
  try {
    await api(`/api/admin/requests/${id}/reject`, { method: 'POST', body: { reason } });
    toast('Request rejected.');
    loadRequests(); loadHome();
  } catch (e) { toast(e.message, true); }
}

/* ---------------- customers ---------------- */
document.getElementById('custSearchBtn').addEventListener('click', loadCustomers);
document.getElementById('custSearch').addEventListener('keydown', (e) => { if (e.key === 'Enter') loadCustomers(); });

async function loadCustomers() {
  const q = document.getElementById('custSearch').value.trim();
  const { customers } = await api(`/api/admin/customers?q=${encodeURIComponent(q)}`);

  document.getElementById('custBody').innerHTML = customers.length
    ? customers.map((c) => `
      <tr>
        <td><strong>${esc(c.name)}</strong><br><span style="font-size:.72rem;opacity:.6">Joined ${dateStr(c.created_at)}</span></td>
        <td style="font-size:.8rem">${esc(c.email)}<br><span style="opacity:.65">${esc(c.phone)}</span></td>
        <td class="right mono">${c.books}</td>
        <td class="right mono">${inrShort(c.principal)}</td>
        <td class="right mono">${inrShort(c.returned)}</td>
        <td>${chipFor(c.kyc_status)}</td>
        <td>${chipFor(c.status)}</td>
        <td class="right" style="white-space:nowrap">
          <button class="linkish" onclick="viewCustomer(${c.id})">Open</button>
        </td>
      </tr>`).join('')
    : `<tr><td colspan="8"><div class="empty"><strong>No customers found</strong>${q ? 'Try a different search.' : 'Nobody has signed up yet.'}</div></td></tr>`;
}

async function viewCustomer(id) {
  const d = await api(`/api/admin/customers/${id}`);
  document.getElementById('custTitle').textContent = d.user.name;
  document.getElementById('custSub').textContent = `${d.user.email} · ${d.user.phone}`;

  document.getElementById('custBodyModal').innerHTML = `
    <div class="row" style="margin-bottom:1.2rem">
      <div class="field">
        <label for="cm_kyc">KYC</label>
        <select class="input" id="cm_kyc">
          ${['pending','verified','rejected'].map((v) => `<option value="${v}" ${d.user.kyc_status === v ? 'selected' : ''}>${v}</option>`).join('')}
        </select>
      </div>
      <div class="field">
        <label for="cm_status">Account</label>
        <select class="input" id="cm_status">
          ${['active','blocked'].map((v) => `<option value="${v}" ${d.user.status === v ? 'selected' : ''}>${v}</option>`).join('')}
        </select>
      </div>
    </div>
    <button class="btn btn--forest btn--sm" onclick="saveCustomer(${id})">Save changes</button>
    <button class="btn btn--ghost btn--sm" onclick="resetPw(${id})">Set a new password</button>

    <h4 style="margin:1.6rem 0 .7rem;font-size:.95rem">Books</h4>
    ${d.investments.length ? `
      <div class="table-wrap"><table class="data">
        <thead><tr><th>Ref</th><th>Book</th><th class="right">In</th><th class="right">Credited</th><th>Status</th></tr></thead>
        <tbody>${d.investments.map((i) => `
          <tr>
            <td class="mono" style="font-size:.74rem">${esc(i.ref_no)}</td>
            <td>${esc(i.plan_name)}</td>
            <td class="right mono">${inr(i.amount)}</td>
            <td class="right mono">${inr(i.returned, 2)}</td>
            <td>${chipFor(i.status)}</td>
          </tr>`).join('')}</tbody>
      </table></div>` : '<p style="font-size:.85rem;color:rgba(12,31,25,.55)">No books yet.</p>'}

    <h4 style="margin:1.6rem 0 .7rem;font-size:.95rem">Credits</h4>
    ${d.payouts.length ? `
      <div class="table-wrap"><table class="data">
        <thead><tr><th>Month</th><th>Ref</th><th class="right">On</th><th class="right">Rate</th><th class="right">Credited</th></tr></thead>
        <tbody>${d.payouts.map((p) => `
          <tr>
            <td class="mono">${monthLabel(p.year, p.month)}</td>
            <td class="mono" style="font-size:.72rem">${esc(p.ref_no)}</td>
            <td class="right mono">${inr(p.principal)}</td>
            <td class="right mono">${pct(p.rate)}</td>
            <td class="right mono" style="color:var(--leaf);font-weight:600">${inr(p.amount, 2)}</td>
          </tr>`).join('')}</tbody>
      </table></div>` : '<p style="font-size:.85rem;color:rgba(12,31,25,.55)">Nothing credited yet.</p>'}`;

  openModal('custModal');
}

async function saveCustomer(id) {
  try {
    await api(`/api/admin/customers/${id}`, {
      method: 'PATCH',
      body: {
        kyc_status: document.getElementById('cm_kyc').value,
        status: document.getElementById('cm_status').value,
      },
    });
    toast('Customer updated.');
    closeModal('custModal');
    loadCustomers();
  } catch (e) { toast(e.message, true); }
}

async function resetPw(id) {
  const pw = prompt('New password for this customer (at least 8 characters). Tell them to change it after signing in.');
  if (!pw) return;
  try {
    await api(`/api/admin/customers/${id}/reset-password`, { method: 'POST', body: { password: pw } });
    toast('Password set.');
  } catch (e) { toast(e.message, true); }
}

/* ---------------- books ---------------- */
document.getElementById('invFilter').addEventListener('click', (e) => {
  if (e.target.tagName !== 'BUTTON') return;
  invStatus = e.target.dataset.s;
  document.querySelectorAll('#invFilter button').forEach((b) =>
    b.setAttribute('aria-pressed', String(b.dataset.s === invStatus)));
  loadInvestments();
});

async function loadInvestments() {
  const { investments } = await api(`/api/admin/investments?status=${invStatus}`);
  document.getElementById('invBody').innerHTML = investments.length
    ? investments.map((i) => `
      <tr>
        <td class="mono" style="font-size:.74rem">${esc(i.ref_no)}</td>
        <td><strong>${esc(i.name)}</strong><br><span style="font-size:.72rem;opacity:.65">${esc(i.phone)}</span></td>
        <td>${esc(i.plan_name)}</td>
        <td class="right mono">${inr(i.amount)}</td>
        <td class="right mono" style="color:var(--leaf)">${inr(i.returned, 2)}</td>
        <td class="mono" style="font-size:.76rem">${i.start_date ? dateStr(i.start_date) : '—'}</td>
        <td>${chipFor(i.status)}</td>
        <td class="right"><button class="linkish" onclick="editInv(${i.id}, '${i.status}', ${i.amount})">Edit</button></td>
      </tr>`).join('')
    : `<tr><td colspan="8"><div class="empty"><strong>No books here</strong>Nothing matches this filter.</div></td></tr>`;
}

async function editInv(id, status, amount) {
  const newStatus = prompt('Set status: active, pending, matured, closed, or rejected', status);
  if (newStatus === null) return;
  const newAmount = prompt('Amount in (₹)', amount);
  if (newAmount === null) return;
  try {
    await api(`/api/admin/investments/${id}`, {
      method: 'PATCH',
      body: { status: newStatus.trim(), amount: Number(newAmount) },
    });
    toast('Book updated.');
    loadInvestments(); loadPlans();
  } catch (e) { toast(e.message, true); }
}

document.getElementById('openCounterBook').addEventListener('click', async () => {
  const { customers } = await api('/api/admin/customers?q=');
  if (!customers.length) return toast('No customers yet. Ask them to sign up first.', true);

  document.getElementById('ct_user').innerHTML = customers.map((c) =>
    `<option value="${c.id}">${esc(c.name)} — ${esc(c.phone)}</option>`).join('');
  document.getElementById('ct_plan').innerHTML = PLANS.filter((p) => p.is_active).map((p) =>
    `<option value="${p.id}">${esc(p.name)} — ${inr(p.min_amount)} to ${inr(p.max_amount)}</option>`).join('');
  document.getElementById('ct_date').value = new Date().toISOString().slice(0, 10);
  document.getElementById('ct_amount').value = PLANS[0]?.min_amount || 10000;
  showError('counterErr', '');
  openModal('counterModal');
});

document.getElementById('counterSave').addEventListener('click', async (e) => {
  showError('counterErr', '');
  await withBusy(e.target, 'Opening…', async () => {
    try {
      const out = await api('/api/admin/investments', {
        method: 'POST',
        body: {
          user_id: Number(document.getElementById('ct_user').value),
          plan_id: Number(document.getElementById('ct_plan').value),
          amount: Number(document.getElementById('ct_amount').value),
          start_date: document.getElementById('ct_date').value,
          note: document.getElementById('ct_note').value,
        },
      });
      closeModal('counterModal');
      toast(`Book opened — ${out.ref_no}`);
      loadInvestments(); loadHome(); loadPlans();
    } catch (err) { showError('counterErr', err.message); }
  });
});

/* ---------------- plans ---------------- */
async function loadPlanTable() {
  await loadPlans();
  document.getElementById('planBody').innerHTML = PLANS.map((p) => `
    <tr>
      <td><strong>${esc(p.name)}</strong><br><span class="mono" style="font-size:.7rem;opacity:.6">${esc(p.code)}</span></td>
      <td class="mono" style="font-size:.78rem">${inrShort(p.min_amount)} – ${inrShort(p.max_amount)}</td>
      <td class="right mono">${pct(p.indicative_rate)}</td>
      <td class="right mono">${p.tenure_months}m${p.lockin_months ? ` / ${p.lockin_months}m lock` : ''}</td>
      <td class="right mono">${p.active_books}</td>
      <td class="right mono">${inrShort(p.principal)}</td>
      <td>${p.is_active ? '<span class="chip chip--active">shown</span>' : '<span class="chip chip--closed">hidden</span>'}</td>
      <td class="right" style="white-space:nowrap">
        <button class="linkish" onclick="editPlan(${p.id})">Edit</button>
        &nbsp;<button class="linkish" style="color:var(--kumkum)" onclick="deletePlan(${p.id})">Remove</button>
      </td>
    </tr>`).join('');
}

document.getElementById('newPlan').addEventListener('click', () => {
  editingPlanId = null;
  document.getElementById('planModalTitle').textContent = 'Add a plan';
  ['code','name','tagline','perks'].forEach((f) => (document.getElementById('pm_' + f).value = ''));
  document.getElementById('pm_min').value = 10000;
  document.getElementById('pm_max').value = 100000;
  document.getElementById('pm_rate').value = 2;
  document.getElementById('pm_tenure').value = 12;
  document.getElementById('pm_lockin').value = 0;
  document.getElementById('pm_sort').value = PLANS.length + 1;
  document.getElementById('pm_active').value = '1';
  showError('planErr', '');
  openModal('planModal');
});

function editPlan(id) {
  const p = PLANS.find((x) => x.id === id);
  if (!p) return;
  editingPlanId = id;
  document.getElementById('planModalTitle').textContent = `Edit ${p.name}`;
  document.getElementById('pm_code').value = p.code;
  document.getElementById('pm_name').value = p.name;
  document.getElementById('pm_tagline').value = p.tagline || '';
  document.getElementById('pm_min').value = p.min_amount;
  document.getElementById('pm_max').value = p.max_amount;
  document.getElementById('pm_rate').value = p.indicative_rate;
  document.getElementById('pm_tenure').value = p.tenure_months;
  document.getElementById('pm_lockin').value = p.lockin_months;
  document.getElementById('pm_sort').value = p.sort_order;
  document.getElementById('pm_perks').value = p.perks || '';
  document.getElementById('pm_active').value = p.is_active ? '1' : '0';
  showError('planErr', '');
  openModal('planModal');
}

document.getElementById('planSave').addEventListener('click', async (e) => {
  showError('planErr', '');
  const body = {
    code: document.getElementById('pm_code').value.trim(),
    name: document.getElementById('pm_name').value.trim(),
    tagline: document.getElementById('pm_tagline').value.trim(),
    min_amount: Number(document.getElementById('pm_min').value),
    max_amount: Number(document.getElementById('pm_max').value),
    indicative_rate: Number(document.getElementById('pm_rate').value),
    tenure_months: Number(document.getElementById('pm_tenure').value),
    lockin_months: Number(document.getElementById('pm_lockin').value),
    sort_order: Number(document.getElementById('pm_sort').value),
    perks: document.getElementById('pm_perks').value,
    is_active: document.getElementById('pm_active').value === '1',
  };

  await withBusy(e.target, 'Saving…', async () => {
    try {
      if (editingPlanId) await api(`/api/admin/plans/${editingPlanId}`, { method: 'PATCH', body });
      else await api('/api/admin/plans', { method: 'POST', body });
      closeModal('planModal');
      toast('Plan saved.');
      loadPlanTable();
    } catch (err) { showError('planErr', err.message); }
  });
});

async function deletePlan(id) {
  const p = PLANS.find((x) => x.id === id);
  if (!confirm(`Remove ${p.name}? If books exist on it, it will be hidden from the site instead of deleted.`)) return;
  try {
    const out = await api(`/api/admin/plans/${id}`, { method: 'DELETE' });
    toast(out.message || 'Plan removed.');
    loadPlanTable();
  } catch (e) { toast(e.message, true); }
}

/* ---------------- rate history ---------------- */
async function loadRates() {
  const { rates } = await api('/api/admin/rates');
  document.getElementById('rateBody').innerHTML = rates.length
    ? rates.map((r) => `
      <tr>
        <td class="mono">${monthLabel(r.year, r.month)}</td>
        <td>${esc(r.plan_name)}</td>
        <td class="right"><span class="pb__rate">${pct(r.rate)}</span></td>
        <td class="right mono">${r.books}</td>
        <td class="right mono">${inr(r.total, 2)}</td>
        <td style="font-size:.8rem">${esc(r.declared_by_name || '—')}<br><span style="font-size:.72rem;opacity:.6">${dateStr(r.declared_at)}</span></td>
        <td style="font-size:.78rem;max-width:180px">${esc(r.note || '')}</td>
        <td class="right"><button class="linkish" style="color:var(--kumkum)" onclick="deleteRate(${r.id})">Undo</button></td>
      </tr>`).join('')
    : `<tr><td colspan="8"><div class="empty"><strong>Nothing declared yet</strong>Declarations appear here once posted.</div></td></tr>`;
}

async function deleteRate(id) {
  if (!confirm('Undo this declaration? Every credit it created is removed from customer passbooks and the public board.')) return;
  try {
    await api(`/api/admin/rates/${id}`, { method: 'DELETE' });
    toast('Declaration undone.');
    loadRates(); loadHome();
  } catch (e) { toast(e.message, true); }
}

/* ---------------- settings ---------------- */
const SETTING_KEYS = ['shop_name','shop_tagline','shop_phone','shop_email','shop_address',
  'bank_name','bank_account','bank_ifsc','upi_id','gold_rate_916','disclaimer'];

async function loadSettings() {
  const { settings } = await api('/api/admin/settings');
  for (const k of SETTING_KEYS) {
    const el = document.getElementById('s_' + k);
    if (el) el.value = settings[k] ?? '';
  }
}

document.getElementById('saveSettings').addEventListener('click', async (e) => {
  showError('setErr', '');
  const body = {};
  for (const k of SETTING_KEYS) {
    const el = document.getElementById('s_' + k);
    if (el) body[k] = el.value;
  }
  await withBusy(e.target, 'Saving…', async () => {
    try {
      await api('/api/admin/settings', { method: 'PUT', body });
      toast('Settings saved.');
    } catch (err) { showError('setErr', err.message); }
  });
});

/* ---------------- sign out ---------------- */
document.getElementById('signOut').addEventListener('click', async () => {
  await api('/api/auth/logout', { method: 'POST' });
  location.href = '/';
});

boot();
