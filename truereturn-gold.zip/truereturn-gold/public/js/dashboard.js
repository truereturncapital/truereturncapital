let D = null;          // dashboard payload
let TX = { mode: null, investment: null, plan: null };

/* ---------------- boot ---------------- */
async function boot() {
  try {
    D = await api('/api/me/dashboard');
  } catch {
    location.href = '/login';
    return;
  }
  if (D.user.role === 'admin') { location.href = '/admin'; return; }

  document.getElementById('whoName').textContent = D.user.name;
  document.getElementById('whoEmail').textContent = D.user.email;

  paintBooks();
  paintPicker();
  paintActivity();
  paintProfile();
  paintPayBox();

  const wanted = new URLSearchParams(location.search).get('plan');
  if (wanted) {
    switchTab('open');
    const plan = D.plans.find((p) => p.id === Number(wanted));
    if (plan) setTimeout(() => startPurchase(plan.id), 250);
    history.replaceState({}, '', '/dashboard');
  } else if (!D.investments.length) {
    switchTab('open');
  }
}

/* ---------------- tabs ---------------- */
function switchTab(name) {
  document.querySelectorAll('.tab').forEach((t) =>
    t.setAttribute('aria-selected', String(t.dataset.panel === name)));
  document.querySelectorAll('.panel').forEach((p) =>
    (p.hidden = p.id !== 'panel-' + name));
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
document.querySelectorAll('.tab').forEach((t) =>
  t.addEventListener('click', () => switchTab(t.dataset.panel)));

/* ---------------- books / passbook ---------------- */
function paintBooks() {
  const stats = document.getElementById('bookStats');
  const list = document.getElementById('booksList');
  const active = D.investments.filter((i) => i.status === 'active');

  stats.innerHTML = `
    <div class="stat">
      <div class="stat__k">Amount in</div>
      <div class="stat__v">${inr(D.totals.principal)}</div>
      <div class="stat__n">${active.length} open book${active.length === 1 ? '' : 's'}</div>
    </div>
    <div class="stat stat--gold">
      <div class="stat__k">Credited so far</div>
      <div class="stat__v">${inr(D.totals.returned, 2)}</div>
      <div class="stat__n">Across every declared month</div>
    </div>
    <div class="stat">
      <div class="stat__k">Book value</div>
      <div class="stat__v">${inr(D.totals.book_value, 2)}</div>
      <div class="stat__n">Amount in plus credits</div>
    </div>
    <div class="stat">
      <div class="stat__k">This month</div>
      <div class="stat__v" style="font-size:1.15rem">${MONTHS_SHORT[D.month.month]} ${D.month.year}</div>
      <div class="stat__n">${active.length ? 'Rates post at month end' : 'No open books yet'}</div>
    </div>`;

  if (!D.investments.length) {
    list.innerHTML = `
      <div class="card"><div class="card__body">
        <div class="empty">
          <strong>Your passbook is empty</strong>
          Open a book and every declared month will be recorded here, line by line.
          <div style="margin-top:1.3rem">
            <button class="btn btn--gold" onclick="switchTab('open')">Open your first book</button>
          </div>
        </div>
      </div></div>`;
    return;
  }

  list.innerHTML = D.investments.map(renderPassbook).join('');
}

function renderPassbook(inv) {
  const isActive = inv.status === 'active';
  const canUpgrade = D.plans.some((p) => p.min_amount > inv.min_amount);

  const pending = inv.pending_requests.map((r) => {
    let label = r.type;
    if (r.type === 'upgrade') {
      try { const m = JSON.parse(r.meta || '{}'); label = `Upgrade to ${m.to_plan || 'a larger book'}`; }
      catch { label = 'Upgrade'; }
    } else if (r.type === 'topup') label = 'Top-up';
    else if (r.type === 'purchase') label = 'Opening request';
    return `
      <div class="pb__pending">
        <span><strong>${esc(label)}</strong> · ${inr(r.amount)} · waiting for the shop to confirm payment</span>
        <button class="btn btn--danger btn--sm" onclick="cancelRequest(${r.id})">Withdraw</button>
      </div>`;
  }).join('');

  const rows = inv.entries.length
    ? inv.entries.map((e) => `
        <tr>
          <td class="pb__month">${MONTHS[e.month]} ${e.year}</td>
          <td><span class="pb__rate">${pct(e.rate)}</span></td>
          <td class="right"><span class="pb__working">${inr(e.principal)} &times; ${pct(e.rate)}</span></td>
          <td class="right pb__credit">+ ${inr(e.amount, 2)}</td>
        </tr>`).join('')
    : `<tr><td colspan="4">
         <div class="empty" style="padding:2.2rem 1rem">
           <strong>No months credited yet</strong>
           ${isActive
             ? 'The first line appears once the shop declares a rate for this book.'
             : 'This book starts earning after the shop confirms your payment.'}
         </div></td></tr>`;

  return `
  <article class="passbook">
    <div class="passbook__spine">
      <div class="pb__top">
        <div>
          <div class="pb__plan">${esc(inv.plan_name)}</div>
          <div class="pb__ref">${esc(inv.ref_no)}</div>
        </div>
        ${chipFor(inv.status)}
      </div>
      <dl class="pb__figures">
        <div class="pb__fig"><dt>Amount in</dt><dd>${inr(inv.amount)}</dd></div>
        <div class="pb__fig"><dt>Credited</dt><dd class="up">${inr(inv.total_returned, 2)}</dd></div>
        <div class="pb__fig"><dt>Months credited</dt><dd>${inv.months_credited}</dd></div>
        ${inv.avg_rate !== null ? `<div class="pb__fig"><dt>Average rate</dt><dd>${pct(inv.avg_rate)}</dd></div>` : ''}
      </dl>
    </div>

    ${pending}

    <div class="pb__actions">
      <span class="pb__meta">
        ${inv.start_date ? `Opened ${dateStr(inv.start_date)}` : 'Not opened yet'}
        ${inv.maturity_date ? ` · matures ${dateStr(inv.maturity_date)}` : ''}
        ${inv.lockin_months ? ` · ${inv.lockin_months}-month lock-in` : ''}
      </span>
      <span class="spacer"></span>
      ${isActive ? `<button class="btn btn--ghost btn--sm" onclick="startTopup(${inv.id})">Add money</button>` : ''}
      ${isActive && canUpgrade ? `<button class="btn btn--gold btn--sm" onclick="startUpgrade(${inv.id})">Move to a bigger book</button>` : ''}
    </div>

    <div class="pb__ledger table-wrap">
      <table style="min-width:520px">
        <thead>
          <tr>
            <th>Month</th><th>Declared rate</th>
            <th class="right">Worked out from</th><th class="right">Credited</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
  </article>`;
}

/* ---------------- plan picker ---------------- */
function paintPicker() {
  document.getElementById('pickGrid').innerHTML = D.plans.map((p) => `
    <button class="pick__card" onclick="startPurchase(${p.id})">
      <div class="pick__name">${esc(p.name)}</div>
      <div style="font-size:.83rem;color:rgba(12,31,25,.6)">${esc(p.tagline || '')}</div>
      <div class="pick__rate ${p.current_rate === null ? 'none' : ''}">
        ${p.current_rate === null ? 'Not declared this month' : pct(p.current_rate)}
      </div>
      <div class="pick__lab">${p.current_rate === null
        ? `Indicative ${pct(p.indicative_rate)}`
        : `Declared for ${MONTHS_SHORT[D.month.month]} ${D.month.year}`}</div>
      <div class="pick__range">
        ${inr(p.min_amount)} – ${inr(p.max_amount)}<br>
        <span style="opacity:.65">${p.tenure_months}-month term</span>
      </div>
    </button>`).join('');
}

function paintPayBox() {
  const p = D.payment;
  document.getElementById('payBox').innerHTML = `
    <strong>Where to pay</strong>
    <dl>
      ${p.upi_id ? `<dt>UPI</dt><dd>${esc(p.upi_id)}</dd>` : ''}
      ${p.bank_name ? `<dt>Bank</dt><dd>${esc(p.bank_name)}</dd>` : ''}
      ${p.bank_account ? `<dt>Account</dt><dd>${esc(p.bank_account)}</dd>` : ''}
      ${p.bank_ifsc ? `<dt>IFSC</dt><dd>${esc(p.bank_ifsc)}</dd>` : ''}
      ${p.shop_phone ? `<dt>Shop</dt><dd>${esc(p.shop_phone)}</dd>` : ''}
    </dl>`;
}

/* ---------------- activity ---------------- */
function paintActivity() {
  const body = document.getElementById('activityBody');
  if (!D.transactions.length) {
    body.innerHTML = `<tr><td colspan="7"><div class="empty"><strong>Nothing yet</strong>Requests you make will be listed here.</div></td></tr>`;
    return;
  }
  const names = { purchase: 'Opened a book', topup: 'Added money', upgrade: 'Moved up a book', return: 'Monthly credit', withdrawal: 'Withdrawal', adjustment: 'Adjustment' };

  body.innerHTML = D.transactions.map((t) => {
    let note = t.meta || '';
    if (t.type === 'upgrade') {
      try { const m = JSON.parse(t.meta || '{}'); if (m.to_plan) note = `To ${m.to_plan}`; } catch { /* plain text */ }
    }
    return `
    <tr>
      <td class="mono" style="white-space:nowrap">${dateStr(t.created_at)}</td>
      <td>${names[t.type] || t.type}</td>
      <td class="mono" style="font-size:.78rem">${esc(t.ref_no || '—')}</td>
      <td class="right mono">${inr(t.amount)}</td>
      <td>${chipFor(t.status)}</td>
      <td style="font-size:.8rem;color:rgba(12,31,25,.6);max-width:220px">${esc(note)}</td>
      <td class="right">${t.status === 'pending'
        ? `<button class="linkish" onclick="cancelRequest(${t.id})">Withdraw</button>` : ''}</td>
    </tr>`;
  }).join('');
}

/* ---------------- profile ---------------- */
function paintProfile() {
  document.getElementById('pfName').value = D.user.name;
  document.getElementById('pfPhone').value = D.user.phone;
  document.getElementById('pfEmail').value = D.user.email;
}

document.getElementById('saveProfile').addEventListener('click', async (e) => {
  showError('profErr', '');
  await withBusy(e.target, 'Saving…', async () => {
    try {
      await api('/api/me/profile', {
        method: 'PATCH',
        body: {
          name: document.getElementById('pfName').value.trim(),
          phone: document.getElementById('pfPhone').value.trim(),
        },
      });
      toast('Details saved.');
      D = await api('/api/me/dashboard');
      document.getElementById('whoName').textContent = D.user.name;
    } catch (err) { showError('profErr', err.message); }
  });
});

document.getElementById('savePw').addEventListener('click', async (e) => {
  showError('pwErr', '');
  const current = document.getElementById('pwCur').value;
  const next = document.getElementById('pwNew').value;
  if (!current || !next) return showError('pwErr', 'Fill in both password fields.');

  await withBusy(e.target, 'Changing…', async () => {
    try {
      await api('/api/auth/password', { method: 'POST', body: { current, next } });
      toast('Password changed.');
      document.getElementById('pwCur').value = '';
      document.getElementById('pwNew').value = '';
    } catch (err) { showError('pwErr', err.message); }
  });
});

/* ---------------- transaction modal ---------------- */
function startPurchase(planId) {
  const plan = D.plans.find((p) => p.id === planId);
  if (!plan) return;
  TX = { mode: 'purchase', plan, investment: null };

  document.getElementById('txTitle').textContent = `Open a ${plan.name} book`;
  document.getElementById('txSub').textContent =
    `${inr(plan.min_amount)} to ${inr(plan.max_amount)} · ${plan.tenure_months}-month term`;
  document.getElementById('txPlanField').hidden = true;
  document.getElementById('txAmountLabel').textContent = 'Amount you want to put in';
  document.getElementById('txAmount').value = plan.min_amount;
  document.getElementById('txHint').textContent =
    `${plan.name} takes ${inr(plan.min_amount)} to ${inr(plan.max_amount)}.`;
  showError('txErr', '');
  renderTxPreview();
  openModal('txModal');
}

function startTopup(invId) {
  const inv = D.investments.find((i) => i.id === invId);
  if (!inv) return;
  TX = { mode: 'topup', plan: null, investment: inv };

  document.getElementById('txTitle').textContent = 'Add money to this book';
  document.getElementById('txSub').textContent = `${inv.plan_name} · ${inv.ref_no}`;
  document.getElementById('txPlanField').hidden = true;
  document.getElementById('txAmountLabel').textContent = 'Amount to add';
  document.getElementById('txAmount').value = 10000;
  const headroom = inv.max_amount - inv.amount;
  document.getElementById('txHint').textContent =
    `You're at ${inr(inv.amount)}. This book holds up to ${inr(inv.max_amount)}, so you can add ${inr(headroom)} more.`;
  showError('txErr', '');
  renderTxPreview();
  openModal('txModal');
}

function startUpgrade(invId) {
  const inv = D.investments.find((i) => i.id === invId);
  if (!inv) return;
  const bigger = D.plans.filter((p) => p.min_amount > inv.min_amount);
  if (!bigger.length) return toast('This is already the largest book.', true);

  TX = { mode: 'upgrade', plan: null, investment: inv };

  document.getElementById('txTitle').textContent = 'Move to a bigger book';
  document.getElementById('txSub').textContent = `Currently ${inv.plan_name} at ${inr(inv.amount)}`;
  const sel = document.getElementById('txPlan');
  sel.innerHTML = bigger.map((p) =>
    `<option value="${p.id}">${esc(p.name)} — ${inr(p.min_amount)} to ${inr(p.max_amount)}</option>`).join('');
  document.getElementById('txPlanField').hidden = false;
  document.getElementById('txAmountLabel').textContent = 'Extra amount you\'ll add';

  const first = bigger[0];
  document.getElementById('txAmount').value = Math.max(0, first.min_amount - inv.amount);
  sel.onchange = () => {
    const t = D.plans.find((p) => p.id === Number(sel.value));
    document.getElementById('txAmount').value = Math.max(0, t.min_amount - inv.amount);
    renderTxPreview();
  };
  showError('txErr', '');
  renderTxPreview();
  openModal('txModal');
}

function renderTxPreview() {
  const box = document.getElementById('txPreview');
  const amount = Number(document.getElementById('txAmount').value) || 0;

  if (TX.mode === 'purchase') {
    const p = TX.plan;
    const monthly = p.current_rate !== null ? (amount * p.current_rate) / 100 : null;
    box.innerHTML = `
      <strong>What this means</strong>
      <dl>
        <dt>Book</dt><dd>${esc(p.name)}</dd>
        <dt>Amount</dt><dd>${inr(amount)}</dd>
        <dt>Term</dt><dd>${p.tenure_months} months</dd>
        <dt>This month's rate</dt><dd>${p.current_rate === null ? 'not declared yet' : pct(p.current_rate)}</dd>
        ${monthly !== null ? `<dt>At that rate</dt><dd>${inr(monthly, 2)} for the month</dd>` : ''}
      </dl>
      <p style="margin:.7rem 0 0;font-size:.76rem;color:rgba(12,31,25,.55);line-height:1.5">
        Next month's rate is declared separately and may differ. Nothing here is a guaranteed return.
      </p>`;
    return;
  }

  const inv = TX.investment;
  if (TX.mode === 'topup') {
    box.innerHTML = `
      <strong>What this means</strong>
      <dl>
        <dt>Book</dt><dd>${esc(inv.plan_name)} · ${esc(inv.ref_no)}</dd>
        <dt>Now</dt><dd>${inr(inv.amount)}</dd>
        <dt>Adding</dt><dd>${inr(amount)}</dd>
        <dt>After</dt><dd>${inr(inv.amount + amount)}</dd>
      </dl>`;
    return;
  }

  if (TX.mode === 'upgrade') {
    const target = D.plans.find((p) => p.id === Number(document.getElementById('txPlan').value));
    const total = inv.amount + amount;
    const short = target && total < target.min_amount ? target.min_amount - total : 0;
    box.innerHTML = `
      <strong>What this means</strong>
      <dl>
        <dt>From</dt><dd>${esc(inv.plan_name)} at ${inr(inv.amount)}</dd>
        <dt>To</dt><dd>${esc(target?.name || '—')}</dd>
        <dt>Adding</dt><dd>${inr(amount)}</dd>
        <dt>New total</dt><dd>${inr(total)}</dd>
      </dl>
      ${short ? `<p style="margin:.7rem 0 0;font-size:.8rem;color:#7C2712">Add ${inr(short)} more to reach the ${esc(target.name)} minimum.</p>` : ''}`;
  }
}

document.getElementById('txAmount').addEventListener('input', renderTxPreview);

document.getElementById('txSubmit').addEventListener('click', async (e) => {
  showError('txErr', '');
  const amount = Number(document.getElementById('txAmount').value) || 0;

  await withBusy(e.target, 'Submitting…', async () => {
    try {
      let out;
      if (TX.mode === 'purchase') {
        out = await api('/api/me/investments', { method: 'POST', body: { plan_id: TX.plan.id, amount } });
      } else if (TX.mode === 'topup') {
        out = await api(`/api/me/investments/${TX.investment.id}/topup`, { method: 'POST', body: { amount } });
      } else {
        out = await api(`/api/me/investments/${TX.investment.id}/upgrade`, {
          method: 'POST',
          body: { amount, plan_id: Number(document.getElementById('txPlan').value) },
        });
      }
      closeModal('txModal');
      toast(out.message || 'Request submitted.');
      await refresh();
      switchTab('books');
    } catch (err) { showError('txErr', err.message); }
  });
});

async function cancelRequest(txId) {
  if (!confirm('Withdraw this request?')) return;
  try {
    await api(`/api/me/transactions/${txId}/cancel`, { method: 'POST' });
    toast('Request withdrawn.');
    await refresh();
  } catch (e) { toast(e.message, true); }
}

async function refresh() {
  D = await api('/api/me/dashboard');
  paintBooks();
  paintPicker();
  paintActivity();
}

document.getElementById('signOut').addEventListener('click', async () => {
  await api('/api/auth/logout', { method: 'POST' });
  location.href = '/';
});

boot();
