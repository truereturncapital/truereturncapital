let DATA = null;

async function boot() {
  try {
    DATA = await api('/api/public/overview');
  } catch (e) {
    toast(e.message, true);
    return;
  }
  paintSettings();
  paintBoard();
  paintPlans();
  paintHistory();
  setupCalculator();
  checkSession();
}

/* ---------------- shop details ---------------- */
function paintSettings() {
  const s = DATA.settings;
  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };

  set('footTagline', s.shop_tagline || '');
  set('footAddress', s.shop_address || '');
  set('discText', s.disclaimer || '');

  const phone = document.getElementById('footPhone');
  if (phone && s.shop_phone) { phone.textContent = s.shop_phone; phone.href = 'tel:' + s.shop_phone.replace(/\s/g, ''); }
  const email = document.getElementById('footEmail');
  if (email && s.shop_email) { email.textContent = s.shop_email; email.href = 'mailto:' + s.shop_email; }

  set('statGold', s.gold_rate_916 ? inr(s.gold_rate_916) + ' /g' : '—');
  set('statBooks', String(DATA.stats.active_books));
  set('statPaid', inrShort(DATA.stats.total_returned));

  if (s.shop_name && s.shop_name !== 'TrueReturn Gold') {
    document.title = `${s.shop_name} — ${s.shop_tagline || 'Gold savings'}`;
  }
}

/* ---------------- the board ---------------- */
function paintBoard() {
  const { year, month } = DATA.month;
  document.getElementById('boardMonth').textContent = `${MONTHS[month]} ${year}`;

  const rows = DATA.plans.map((p) => `
    <div class="board__row">
      <div>
        <div class="board__name">${esc(p.name)}</div>
        <span class="board__range">${inrShort(p.min_amount)} – ${inrShort(p.max_amount)}</span>
      </div>
      <div class="board__rate ${p.current_rate === null ? 'board__rate--none' : ''}">
        ${p.current_rate === null
          ? 'not yet declared'
          : `${Number(p.current_rate).toFixed(2)}<sup>%</sup>`}
      </div>
    </div>`).join('');

  document.getElementById('boardRows').innerHTML =
    rows || '<div class="board__row"><div class="board__name">No plans open yet.</div></div>';

  const declared = DATA.plans.filter((p) => p.current_rate !== null).length;
  document.getElementById('boardFoot').textContent = declared
    ? `${declared} of ${DATA.plans.length} books declared for ${MONTHS[month]}. Rates are set month by month and are not guaranteed.`
    : `Nothing declared for ${MONTHS[month]} yet. Rates are set month by month and are not guaranteed.`;
}

/* ---------------- plan cards ---------------- */
function paintPlans() {
  const grid = document.getElementById('planGrid');
  if (!DATA.plans.length) {
    grid.innerHTML = '<div class="empty"><strong>No books are open</strong>Check back shortly.</div>';
    return;
  }

  grid.innerHTML = DATA.plans.map((p, i) => {
    const rates = p.history.map((h) => h.rate);
    const hi = Math.max(...rates, 0);
    const lo = Math.min(...rates, hi);
    const span = hi - lo;
    // With a flat span every bar would be identical; show them level instead of
    // faking variation. Otherwise spread across the observed range so the
    // month-to-month difference is actually visible.
    const barHeight = (r) => (span > 0 ? 25 + ((r - lo) / span) * 75 : 60);
    const spark = p.history.length > 1
      ? `<div class="plan__spark" title="Last ${p.history.length} declared months">
           ${p.history.map((h) => `<i style="height:${barHeight(h.rate)}%" title="${monthLabel(h.year, h.month)}: ${pct(h.rate)}"></i>`).join('')}
         </div>`
      : '';

    return `
    <article class="plan">
      <div class="plan__tier">Book ${String(i + 1).padStart(2, '0')} · ${esc(p.code)}</div>
      <h3>${esc(p.name)}</h3>
      <p class="plan__tag">${esc(p.tagline || '')}</p>

      <div class="plan__band">
        <div class="plan__rate ${p.current_rate === null ? 'plan__rate--none' : ''}">
          ${p.current_rate === null
            ? 'Not declared this month'
            : `${Number(p.current_rate).toFixed(2)}<sup>%</sup>`}
        </div>
        <div class="plan__ratelabel">
          ${p.current_rate === null
            ? `Indicative ${pct(p.indicative_rate)} · unconfirmed`
            : `Declared for ${MONTHS_SHORT[DATA.month.month]} ${DATA.month.year}`}
        </div>
      </div>

      ${spark}

      <div class="plan__amt">
        ${inr(p.min_amount)} – ${inr(p.max_amount)}<br>
        <span style="opacity:.65">${p.tenure_months}-month term${p.lockin_months ? ` · ${p.lockin_months}-month lock-in` : ''}</span>
        ${p.months_declared ? `<br><span style="opacity:.65">${p.months_declared} month${p.months_declared === 1 ? '' : 's'} declared, averaging ${pct(p.avg_rate)}</span>` : ''}
      </div>

      <ul class="plan__perks">${p.perks.map((k) => `<li>${esc(k)}</li>`).join('')}</ul>
      <a class="btn btn--forest btn--block" href="/signup?plan=${p.id}">Open this book</a>
    </article>`;
  }).join('');
}

/* ---------------- history table ---------------- */
function paintHistory() {
  const head = document.getElementById('historyHead');
  const body = document.getElementById('historyBody');

  const months = new Map();
  for (const p of DATA.plans)
    for (const h of p.history) months.set(`${h.year}-${h.month}`, { year: h.year, month: h.month });

  const ordered = [...months.values()].sort((a, b) => b.year - a.year || b.month - a.month);

  if (!ordered.length) {
    head.innerHTML = '<th>Month</th>';
    body.innerHTML = `<tr><td><div class="empty"><strong>No months declared yet</strong>The first declaration will appear here.</div></td></tr>`;
    return;
  }

  head.innerHTML = '<th>Month</th>' + DATA.plans.map((p) => `<th class="right">${esc(p.name)}</th>`).join('');

  body.innerHTML = ordered.map((m) => {
    const cells = DATA.plans.map((p) => {
      const hit = p.history.find((h) => h.year === m.year && h.month === m.month);
      return `<td class="right ${hit ? 'rate-cell' : ''}" style="${hit ? '' : 'opacity:.3'}">${hit ? pct(hit.rate) : '—'}</td>`;
    }).join('');
    return `<tr><td class="mono">${MONTHS[m.month]} ${m.year}</td>${cells}</tr>`;
  }).join('');
}

/* ---------------- calculator ---------------- */
function setupCalculator() {
  const sel = document.getElementById('calcPlan');
  const amt = document.getElementById('calcAmount');
  const rng = document.getElementById('calcRange');
  const mon = document.getElementById('calcMonths');
  if (!sel || !DATA.plans.length) return;

  sel.innerHTML = DATA.plans.map((p) =>
    `<option value="${p.id}">${esc(p.name)} — ${inrShort(p.min_amount)} to ${inrShort(p.max_amount)}</option>`).join('');

  function currentPlan() {
    return DATA.plans.find((p) => p.id === Number(sel.value)) || DATA.plans[0];
  }

  function syncRange() {
    const p = currentPlan();
    rng.min = p.min_amount;
    rng.max = p.max_amount;
    rng.step = Math.max(1000, Math.round((p.max_amount - p.min_amount) / 100 / 1000) * 1000);
    document.getElementById('calcRangeHint').textContent =
      `${esc(p.name)} takes ${inr(p.min_amount)} to ${inr(p.max_amount)}.`;
    let v = Number(amt.value);
    if (v < p.min_amount || v > p.max_amount) {
      v = Math.min(Math.max(v || p.min_amount, p.min_amount), p.max_amount);
      amt.value = v;
    }
    rng.value = v;
  }

  function render() {
    const p = currentPlan();
    const principal = Math.min(Math.max(Number(amt.value) || 0, p.min_amount), p.max_amount);
    const months = Math.min(Math.max(Number(mon.value) || 1, 1), 60);
    const rate = p.current_rate;

    document.getElementById('calcPrincipal').textContent = inr(principal);

    if (rate === null) {
      document.getElementById('calcTotal').textContent = 'Not declared';
      document.getElementById('calcSub').textContent =
        `${p.name} has no rate posted for ${MONTHS[DATA.month.month]}. Nothing to calculate yet.`;
      document.getElementById('calcRate').textContent = '—';
      document.getElementById('calcMonthly').textContent = '—';
      document.getElementById('calcReturn').textContent = '—';
      return;
    }

    const monthly = (principal * rate) / 100;
    const total = monthly * months;

    document.getElementById('calcRate').textContent = pct(rate);
    document.getElementById('calcMonthly').textContent = inr(monthly, 2);
    document.getElementById('calcReturn').textContent = inr(total, 2);
    document.getElementById('calcTotal').textContent = inr(principal + total);
    document.getElementById('calcSub').textContent =
      `${inr(principal)} plus ${inr(total)} across ${months} month${months === 1 ? '' : 's'}, if ${pct(rate)} repeated every month.`;
  }

  sel.addEventListener('change', () => { syncRange(); render(); });
  amt.addEventListener('input', () => { rng.value = amt.value; render(); });
  rng.addEventListener('input', () => { amt.value = rng.value; render(); });
  mon.addEventListener('input', render);

  const preferred = DATA.plans.find((p) => p.current_rate !== null) || DATA.plans[0];
  sel.value = preferred.id;
  amt.value = Math.min(Math.max(100000, preferred.min_amount), preferred.max_amount);
  syncRange();
  render();
}

/* ---------------- session-aware nav ---------------- */
async function checkSession() {
  try {
    const { user } = await api('/api/auth/me');
    const cta = document.getElementById('navCta');
    const dest = user.role === 'admin' ? '/admin' : '/dashboard';
    cta.innerHTML = `
      <span style="color:rgba(251,246,234,.6);font-size:.85rem" class="nav__hi">Hi, ${esc(user.name.split(' ')[0])}</span>
      <a class="btn btn--gold btn--sm" href="${dest}">${user.role === 'admin' ? 'Admin panel' : 'Your passbook'}</a>`;
  } catch { /* signed out — leave the default buttons */ }
}

boot();
