/* Shared helpers for every page. */

const MONTHS = ['', 'January','February','March','April','May','June',
                'July','August','September','October','November','December'];
const MONTHS_SHORT = ['', 'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

async function api(path, options = {}) {
  const res = await fetch(path, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Try again.');
  return data;
}

/** ₹1,25,000 — Indian grouping, no decimals unless asked. */
function inr(n, decimals = 0) {
  const v = Number(n) || 0;
  return '₹' + v.toLocaleString('en-IN', {
    minimumFractionDigits: decimals, maximumFractionDigits: decimals,
  });
}

/** 1.25 L / 10 L — compact for tight spaces. */
function inrShort(n) {
  const v = Number(n) || 0;
  // Truncate, never round up: a ₹1,99,999 cap must not display as "₹2 L".
  const cut = (x, d) => Math.floor(x * 10 ** d) / 10 ** d;
  if (v >= 10000000) return '₹' + cut(v / 10000000, 2) + ' Cr';
  if (v >= 100000)   return '₹' + cut(v / 100000, 2) + ' L';
  if (v >= 1000)     return '₹' + cut(v / 1000, 1) + 'k';
  return '₹' + v;
}

function pct(n) {
  const v = Number(n);
  return Number.isFinite(v) ? v.toFixed(2) + '%' : '—';
}

function dateStr(s) {
  if (!s) return '—';
  const d = new Date(s.includes('T') || s.includes(' ') ? s.replace(' ', 'T') : s + 'T00:00:00');
  if (isNaN(d)) return s;
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function monthLabel(year, month) { return `${MONTHS_SHORT[month] || month} ${year}`; }

function toast(msg, isError = false) {
  const el = document.getElementById('toast');
  if (!el) return alert(msg);
  el.textContent = msg;
  el.classList.toggle('err', !!isError);
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 3800);
}

function chipFor(status) {
  const map = {
    active: 'active', approved: 'active', verified: 'active',
    pending: 'pending',
    matured: 'closed', closed: 'closed', blocked: 'closed',
    rejected: 'rejected',
  };
  return `<span class="chip chip--${map[status] || 'closed'}">${status}</span>`;
}

/** Escape untrusted text before putting it in innerHTML. */
function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* --- Modal ------------------------------------------------------- */
let _lastFocus = null;
function openModal(id) {
  const el = document.getElementById(id);
  if (!el) return;
  _lastFocus = document.activeElement;
  el.hidden = false;
  const focusable = el.querySelector('input,select,textarea,button');
  if (focusable) setTimeout(() => focusable.focus(), 40);
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.hidden = true;
  if (_lastFocus) _lastFocus.focus();
}
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  document.querySelectorAll('.modal-back:not([hidden])').forEach((m) => (m.hidden = true));
});
document.addEventListener('click', (e) => {
  if (e.target.classList?.contains('modal-back')) e.target.hidden = true;
});

/** Put an error message into a .notice element, or clear it. */
function showError(elId, msg) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = msg || '';
  el.className = msg ? 'notice notice--err' : 'notice';
}

/** Run an async handler with a button in a loading state. */
async function withBusy(btn, label, fn) {
  if (!btn) return fn();
  const original = btn.textContent;
  btn.disabled = true;
  btn.textContent = label;
  try { return await fn(); }
  finally { btn.disabled = false; btn.textContent = original; }
}

const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();
