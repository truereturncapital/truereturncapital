require('dotenv').config();
const bcrypt = require('bcryptjs');
const { db, setSetting } = require('./db');

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@truereturngold.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Admin@12345';

console.log('Seeding TrueReturn Gold…');

// ---- Shop settings -----------------------------------------------------
const defaults = {
  shop_name: 'TrueReturn Gold',
  shop_tagline: 'Gold savings, declared in the open.',
  shop_phone: '+91 00000 00000',
  shop_email: 'care@truereturngold.com',
  shop_address: 'Main Road, Kerala',
  shop_whatsapp: '910000000000',
  bank_name: 'Your Bank',
  bank_account: '0000 0000 0000',
  bank_ifsc: 'XXXX0000000',
  upi_id: 'truereturngold@upi',
  gold_rate_916: '7250',
  disclaimer:
    'Returns shown are declared month by month and are not guaranteed. Past declarations do not promise future ones.',
};
for (const [k, v] of Object.entries(defaults)) {
  const exists = db.prepare('SELECT 1 FROM settings WHERE key=?').get(k);
  if (!exists) setSetting(k, v);
}

// ---- Admin -------------------------------------------------------------
const existingAdmin = db.prepare('SELECT id FROM users WHERE email=?').get(ADMIN_EMAIL);
if (!existingAdmin) {
  db.prepare(
    `INSERT INTO users(name,email,phone,password_hash,role,kyc_status)
     VALUES(?,?,?,?,'admin','verified')`
  ).run('Store Admin', ADMIN_EMAIL, defaults.shop_phone, bcrypt.hashSync(ADMIN_PASSWORD, 10));
  console.log(`  admin created  →  ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}`);
} else {
  console.log('  admin already exists, skipped');
}

// ---- Plans -------------------------------------------------------------
const plans = [
  {
    code: 'MUKHAM',
    name: 'Mukham',
    tagline: 'The starter book. Open it with one month of savings.',
    min_amount: 10000,
    max_amount: 49999,
    indicative_rate: 2.0,
    tenure_months: 12,
    lockin_months: 3,
    perks: 'Monthly rate declared publicly\nPassbook access online\nFree ring sizing & polish',
    sort_order: 1,
  },
  {
    code: 'KASAVU',
    name: 'Kasavu',
    tagline: 'For the family that buys gold every festival.',
    min_amount: 50000,
    max_amount: 199999,
    indicative_rate: 2.75,
    tenure_months: 12,
    lockin_months: 3,
    perks:
      'Everything in Mukham\nMaking-charge waiver up to 4%\nPriority billing counter\nFestival preview access',
    sort_order: 2,
  },
  {
    code: 'THANKAM',
    name: 'Thankam',
    tagline: 'Our mid-book. Where most families settle.',
    min_amount: 200000,
    max_amount: 499999,
    indicative_rate: 3.5,
    tenure_months: 18,
    lockin_months: 6,
    perks:
      'Everything in Kasavu\nMaking-charge waiver up to 8%\nDedicated relationship manager\nFree locker consultation\nAnnual purity re-assay',
    sort_order: 3,
  },
  {
    code: 'PADMA',
    name: 'Padma',
    tagline: 'The full book. Ten lakh, and the shop opens for you.',
    min_amount: 500000,
    max_amount: 1000000,
    indicative_rate: 4.5,
    tenure_months: 24,
    lockin_months: 6,
    perks:
      'Everything in Thankam\nMaking-charge waiver up to 12%\nPrivate viewing room\nCustom design commissions\nDoorstep delivery, insured\nInvitation to the annual account reading',
    sort_order: 4,
  },
];

const insertPlan = db.prepare(
  `INSERT INTO plans(code,name,tagline,min_amount,max_amount,indicative_rate,tenure_months,lockin_months,perks,sort_order)
   VALUES(@code,@name,@tagline,@min_amount,@max_amount,@indicative_rate,@tenure_months,@lockin_months,@perks,@sort_order)
   ON CONFLICT(code) DO NOTHING`
);
for (const p of plans) insertPlan.run(p);
console.log(`  ${plans.length} plans ready`);

// ---- Demo customer (only if DB is otherwise empty of customers) ---------
const customerCount = db.prepare(`SELECT COUNT(*) c FROM users WHERE role='customer'`).get().c;
if (customerCount === 0 && process.env.SEED_DEMO !== 'false') {
  const hash = bcrypt.hashSync('Demo@12345', 10);
  const u = db
    .prepare(
      `INSERT INTO users(name,email,phone,password_hash,kyc_status) VALUES(?,?,?,?,'verified')`
    )
    .run('Demo Customer', 'demo@truereturngold.com', '+91 99999 00000', hash);

  const plan = db.prepare(`SELECT * FROM plans WHERE code='KASAVU'`).get();
  const ref = 'TRG-' + String(Date.now()).slice(-8);
  const inv = db
    .prepare(
      `INSERT INTO investments(user_id,plan_id,amount,status,ref_no,start_date,maturity_date)
       VALUES(?,?,?, 'active', ?, date('now','-4 months'), date('now','-4 months','+12 months'))`
    )
    .run(u.lastInsertRowid, plan.id, 75000, ref);

  db.prepare(
    `INSERT INTO transactions(user_id,investment_id,type,amount,status,meta,settled_at)
     VALUES(?,?,'purchase',75000,'approved','Seeded demo purchase',datetime('now','-4 months'))`
  ).run(u.lastInsertRowid, inv.lastInsertRowid);

  console.log('  demo customer  →  demo@truereturngold.com / Demo@12345');
}

console.log('Done.');
