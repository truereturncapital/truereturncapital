const express = require('express');
const bcrypt = require('bcryptjs');
const { db, getSetting, audit } = require('../db');
const { setAuthCookie, clearAuthCookie, requireAuth } = require('../auth');

const router = express.Router();

const money = (n) => Math.round(Number(n) || 0);
const nowYM = () => {
  const d = new Date();
  return { year: d.getFullYear(), month: d.getMonth() + 1 };
};

/* ------------------------------------------------------------------ */
/* Public                                                              */
/* ------------------------------------------------------------------ */

// Shop settings + plans + this month's declared rate for each plan.
router.get('/public/overview', (req, res) => {
  const keys = [
    'shop_name', 'shop_tagline', 'shop_phone', 'shop_email', 'shop_address',
    'shop_whatsapp', 'gold_rate_916', 'disclaimer', 'upi_id',
  ];
  const settings = {};
  for (const k of keys) settings[k] = getSetting(k, '');

  const plans = db
    .prepare('SELECT * FROM plans WHERE is_active=1 ORDER BY sort_order, min_amount')
    .all();

  const { year, month } = nowYM();

  for (const p of plans) {
    const current = db
      .prepare('SELECT rate, note, declared_at FROM monthly_rates WHERE plan_id=? AND year=? AND month=?')
      .get(p.id, year, month);

    // Last 6 declared months, newest first.
    const history = db
      .prepare(
        `SELECT year, month, rate FROM monthly_rates
         WHERE plan_id=? ORDER BY year DESC, month DESC LIMIT 6`
      )
      .all(p.id);

    const avg = db
      .prepare('SELECT AVG(rate) a, COUNT(*) c FROM monthly_rates WHERE plan_id=?')
      .get(p.id);

    p.perks = (p.perks || '').split('\n').filter(Boolean);
    p.current_rate = current ? current.rate : null;
    p.current_rate_note = current ? current.note : null;
    p.declared_for = { year, month };
    p.history = history.reverse();
    p.avg_rate = avg.c ? Number(avg.a.toFixed(2)) : null;
    p.months_declared = avg.c;
  }

  const stats = db
    .prepare(
      `SELECT
         (SELECT COUNT(*) FROM users WHERE role='customer') AS customers,
         (SELECT COUNT(*) FROM investments WHERE status='active') AS active_books,
         (SELECT IFNULL(SUM(amount),0) FROM payouts) AS total_returned`
    )
    .get();

  res.json({ settings, plans, stats, month: { year, month } });
});

/* ------------------------------------------------------------------ */
/* Auth                                                                */
/* ------------------------------------------------------------------ */

router.post('/auth/signup', (req, res) => {
  const name = String(req.body.name || '').trim();
  const email = String(req.body.email || '').trim().toLowerCase();
  const phone = String(req.body.phone || '').trim();
  const password = String(req.body.password || '');

  if (name.length < 2) return res.status(400).json({ error: 'Enter your full name.' });
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))
    return res.status(400).json({ error: 'Enter a valid email address.' });
  if (phone.replace(/\D/g, '').length < 10)
    return res.status(400).json({ error: 'Enter a 10-digit mobile number.' });
  if (password.length < 8)
    return res.status(400).json({ error: 'Password needs at least 8 characters.' });

  const taken = db.prepare('SELECT 1 FROM users WHERE email=?').get(email);
  if (taken) return res.status(409).json({ error: 'That email already has an account. Sign in instead.' });

  const info = db
    .prepare('INSERT INTO users(name,email,phone,password_hash) VALUES(?,?,?,?)')
    .run(name, email, phone, bcrypt.hashSync(password, 10));

  const user = db.prepare('SELECT id,name,email,phone,role,kyc_status FROM users WHERE id=?').get(info.lastInsertRowid);
  audit(user.id, 'signup', { email });
  setAuthCookie(res, user);
  res.json({ user });
});

router.post('/auth/login', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);

  if (!user || !bcrypt.compareSync(password, user.password_hash))
    return res.status(401).json({ error: 'Email or password is wrong.' });
  if (user.status !== 'active')
    return res.status(403).json({ error: 'This account is on hold. Call the shop.' });

  setAuthCookie(res, user);
  audit(user.id, 'login', {});
  res.json({
    user: { id: user.id, name: user.name, email: user.email, phone: user.phone, role: user.role, kyc_status: user.kyc_status },
  });
});

router.post('/auth/logout', (req, res) => {
  clearAuthCookie(res);
  res.json({ ok: true });
});

router.get('/auth/me', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in.' });
  res.json({ user: req.user });
});

router.post('/auth/password', requireAuth, (req, res) => {
  const current = String(req.body.current || '');
  const next = String(req.body.next || '');
  if (next.length < 8) return res.status(400).json({ error: 'New password needs at least 8 characters.' });
  const row = db.prepare('SELECT password_hash FROM users WHERE id=?').get(req.user.id);
  if (!bcrypt.compareSync(current, row.password_hash))
    return res.status(401).json({ error: 'Current password is wrong.' });
  db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(bcrypt.hashSync(next, 10), req.user.id);
  audit(req.user.id, 'password_change', {});
  res.json({ ok: true });
});

/* ------------------------------------------------------------------ */
/* Customer dashboard                                                  */
/* ------------------------------------------------------------------ */

function buildPassbook(userId) {
  const investments = db
    .prepare(
      `SELECT i.*, p.name AS plan_name, p.code AS plan_code, p.tagline, p.tenure_months,
              p.lockin_months, p.min_amount, p.max_amount, p.perks
       FROM investments i JOIN plans p ON p.id=i.plan_id
       WHERE i.user_id=? ORDER BY i.created_at DESC`
    )
    .all(userId);

  for (const inv of investments) {
    inv.perks = (inv.perks || '').split('\n').filter(Boolean);
    inv.entries = db
      .prepare(
        `SELECT year, month, principal, rate, amount, created_at
         FROM payouts WHERE investment_id=? ORDER BY year DESC, month DESC`
      )
      .all(inv.id);
    const sum = db
      .prepare('SELECT IFNULL(SUM(amount),0) t, COUNT(*) c FROM payouts WHERE investment_id=?')
      .get(inv.id);
    inv.total_returned = Number(sum.t.toFixed(2));
    inv.months_credited = sum.c;
    inv.avg_rate = sum.c
      ? Number(
          (
            db.prepare('SELECT AVG(rate) a FROM payouts WHERE investment_id=?').get(inv.id).a
          ).toFixed(2)
        )
      : null;
    inv.pending_requests = db
      .prepare(
        `SELECT id,type,amount,meta,created_at FROM transactions
         WHERE investment_id=? AND status='pending' ORDER BY created_at DESC`
      )
      .all(inv.id);
  }
  return investments;
}

router.get('/me/dashboard', requireAuth, (req, res) => {
  const investments = buildPassbook(req.user.id);
  const totals = db
    .prepare(
      `SELECT
        (SELECT IFNULL(SUM(amount),0) FROM investments WHERE user_id=? AND status='active') AS principal,
        (SELECT IFNULL(SUM(amount),0) FROM payouts WHERE user_id=?) AS returned`
    )
    .get(req.user.id, req.user.id);

  const transactions = db
    .prepare(
      `SELECT t.*, i.ref_no FROM transactions t
       LEFT JOIN investments i ON i.id=t.investment_id
       WHERE t.user_id=? ORDER BY t.created_at DESC LIMIT 50`
    )
    .all(req.user.id);

  const plans = db.prepare('SELECT * FROM plans WHERE is_active=1 ORDER BY sort_order').all();
  const { year, month } = nowYM();
  for (const p of plans) {
    p.perks = (p.perks || '').split('\n').filter(Boolean);
    const cur = db
      .prepare('SELECT rate FROM monthly_rates WHERE plan_id=? AND year=? AND month=?')
      .get(p.id, year, month);
    p.current_rate = cur ? cur.rate : null;
  }

  res.json({
    user: req.user,
    investments,
    transactions,
    plans,
    totals: {
      principal: totals.principal,
      returned: Number(totals.returned.toFixed(2)),
      book_value: Number((totals.principal + totals.returned).toFixed(2)),
    },
    payment: {
      upi_id: getSetting('upi_id', ''),
      bank_name: getSetting('bank_name', ''),
      bank_account: getSetting('bank_account', ''),
      bank_ifsc: getSetting('bank_ifsc', ''),
      shop_phone: getSetting('shop_phone', ''),
      shop_whatsapp: getSetting('shop_whatsapp', ''),
    },
    month: { year, month },
  });
});

// Open a new book (request — admin must approve once money is received)
router.post('/me/investments', requireAuth, (req, res) => {
  const planId = Number(req.body.plan_id);
  const amount = money(req.body.amount);
  const plan = db.prepare('SELECT * FROM plans WHERE id=? AND is_active=1').get(planId);

  if (!plan) return res.status(400).json({ error: 'That plan is not open right now.' });
  if (amount < plan.min_amount)
    return res.status(400).json({ error: `${plan.name} starts at ₹${plan.min_amount.toLocaleString('en-IN')}.` });
  if (amount > plan.max_amount)
    return res.status(400).json({ error: `${plan.name} tops out at ₹${plan.max_amount.toLocaleString('en-IN')}.` });

  const ref = 'TRG-' + Date.now().toString(36).toUpperCase().slice(-6) + '-' + req.user.id;
  const info = db
    .prepare(`INSERT INTO investments(user_id,plan_id,amount,status,ref_no,note) VALUES(?,?,?,'pending',?,?)`)
    .run(req.user.id, plan.id, amount, ref, String(req.body.note || '').slice(0, 300));

  db.prepare(
    `INSERT INTO transactions(user_id,investment_id,type,amount,status,meta)
     VALUES(?,?,'purchase',?,'pending',?)`
  ).run(req.user.id, info.lastInsertRowid, amount, `New ${plan.name} book`);

  audit(req.user.id, 'investment_requested', { plan: plan.code, amount, ref });
  res.json({ ok: true, ref_no: ref, message: 'Request received. It opens once the shop confirms your payment.' });
});

// Add to an existing book
router.post('/me/investments/:id/topup', requireAuth, (req, res) => {
  const inv = db
    .prepare('SELECT i.*, p.max_amount, p.name plan_name FROM investments i JOIN plans p ON p.id=i.plan_id WHERE i.id=? AND i.user_id=?')
    .get(req.params.id, req.user.id);
  if (!inv) return res.status(404).json({ error: 'Book not found.' });
  if (inv.status !== 'active') return res.status(400).json({ error: 'This book is not open for top-ups yet.' });

  const amount = money(req.body.amount);
  if (amount < 1000) return res.status(400).json({ error: 'Minimum top-up is ₹1,000.' });
  if (inv.amount + amount > inv.max_amount)
    return res.status(400).json({
      error: `${inv.plan_name} holds up to ₹${inv.max_amount.toLocaleString('en-IN')}. Upgrade to add more.`,
    });

  db.prepare(
    `INSERT INTO transactions(user_id,investment_id,type,amount,status,meta)
     VALUES(?,?,'topup',?,'pending',?)`
  ).run(req.user.id, inv.id, amount, `Top-up on ${inv.ref_no}`);

  audit(req.user.id, 'topup_requested', { ref: inv.ref_no, amount });
  res.json({ ok: true, message: 'Top-up requested. It is added once the shop confirms your payment.' });
});

// Move a book to a bigger plan
router.post('/me/investments/:id/upgrade', requireAuth, (req, res) => {
  const inv = db
    .prepare('SELECT i.*, p.sort_order, p.name plan_name FROM investments i JOIN plans p ON p.id=i.plan_id WHERE i.id=? AND i.user_id=?')
    .get(req.params.id, req.user.id);
  if (!inv) return res.status(404).json({ error: 'Book not found.' });
  if (inv.status !== 'active') return res.status(400).json({ error: 'This book is not open for upgrades yet.' });

  const target = db.prepare('SELECT * FROM plans WHERE id=? AND is_active=1').get(Number(req.body.plan_id));
  if (!target) return res.status(400).json({ error: 'That plan is not open right now.' });
  if (target.sort_order <= inv.sort_order)
    return res.status(400).json({ error: 'Pick a plan above your current one.' });

  const addition = money(req.body.amount);
  const newTotal = inv.amount + addition;
  if (newTotal < target.min_amount)
    return res.status(400).json({
      error: `${target.name} needs ₹${target.min_amount.toLocaleString('en-IN')}. Add ₹${(target.min_amount - inv.amount).toLocaleString('en-IN')} more.`,
    });
  if (newTotal > target.max_amount)
    return res.status(400).json({ error: `${target.name} tops out at ₹${target.max_amount.toLocaleString('en-IN')}.` });

  db.prepare(
    `INSERT INTO transactions(user_id,investment_id,type,amount,status,meta)
     VALUES(?,?,'upgrade',?,'pending',?)`
  ).run(req.user.id, inv.id, addition, JSON.stringify({ to_plan_id: target.id, to_plan: target.name, new_total: newTotal }));

  audit(req.user.id, 'upgrade_requested', { ref: inv.ref_no, to: target.code, addition });
  res.json({ ok: true, message: `Upgrade to ${target.name} requested. It applies once the shop confirms your payment.` });
});

// Cancel a request the customer made by mistake
router.post('/me/transactions/:id/cancel', requireAuth, (req, res) => {
  const tx = db.prepare(`SELECT * FROM transactions WHERE id=? AND user_id=? AND status='pending'`).get(req.params.id, req.user.id);
  if (!tx) return res.status(404).json({ error: 'Nothing pending with that reference.' });
  db.prepare(`UPDATE transactions SET status='rejected', meta=?, settled_at=datetime('now') WHERE id=?`)
    .run('Withdrawn by customer', tx.id);
  if (tx.type === 'purchase') {
    db.prepare(`UPDATE investments SET status='rejected' WHERE id=? AND status='pending'`).run(tx.investment_id);
  }
  res.json({ ok: true });
});

router.patch('/me/profile', requireAuth, (req, res) => {
  const name = String(req.body.name || '').trim();
  const phone = String(req.body.phone || '').trim();
  if (name.length < 2) return res.status(400).json({ error: 'Enter your full name.' });
  if (phone.replace(/\D/g, '').length < 10) return res.status(400).json({ error: 'Enter a 10-digit mobile number.' });
  db.prepare('UPDATE users SET name=?, phone=? WHERE id=?').run(name, phone, req.user.id);
  res.json({ ok: true });
});

module.exports = router;
