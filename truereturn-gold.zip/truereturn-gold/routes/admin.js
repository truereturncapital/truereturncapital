const express = require('express');
const bcrypt = require('bcryptjs');
const { db, setSetting, getSetting, audit } = require('../db');
const { requireAdmin } = require('../auth');

const router = express.Router();
router.use(requireAdmin);

const money = (n) => Math.round(Number(n) || 0);
const addMonths = (isoDate, n) => {
  const d = new Date(isoDate);
  d.setMonth(d.getMonth() + n);
  return d.toISOString().slice(0, 10);
};

/* ------------------------------------------------------------------ */
/* Overview                                                            */
/* ------------------------------------------------------------------ */

router.get('/stats', (req, res) => {
  const s = db
    .prepare(
      `SELECT
        (SELECT COUNT(*) FROM users WHERE role='customer') customers,
        (SELECT COUNT(*) FROM users WHERE role='customer' AND created_at >= date('now','-30 days')) customers_30d,
        (SELECT COUNT(*) FROM investments WHERE status='active') active_books,
        (SELECT IFNULL(SUM(amount),0) FROM investments WHERE status='active') principal,
        (SELECT IFNULL(SUM(amount),0) FROM payouts) returned,
        (SELECT COUNT(*) FROM transactions WHERE status='pending') pending_requests,
        (SELECT COUNT(*) FROM investments WHERE status='pending') pending_books`
    )
    .get();

  const byPlan = db
    .prepare(
      `SELECT p.id, p.code, p.name, p.min_amount, p.max_amount,
              COUNT(i.id) books,
              IFNULL(SUM(i.amount),0) principal
       FROM plans p LEFT JOIN investments i ON i.plan_id=p.id AND i.status='active'
       GROUP BY p.id ORDER BY p.sort_order`
    )
    .all();

  const d = new Date();
  const year = d.getFullYear();
  const month = d.getMonth() + 1;
  for (const p of byPlan) {
    const r = db.prepare('SELECT rate FROM monthly_rates WHERE plan_id=? AND year=? AND month=?').get(p.id, year, month);
    p.current_rate = r ? r.rate : null;
    p.this_month_cost = r ? Number(((p.principal * r.rate) / 100).toFixed(2)) : null;
  }

  const recent = db
    .prepare(
      `SELECT t.id,t.type,t.amount,t.status,t.created_at,u.name,u.email,i.ref_no
       FROM transactions t JOIN users u ON u.id=t.user_id
       LEFT JOIN investments i ON i.id=t.investment_id
       ORDER BY t.created_at DESC LIMIT 12`
    )
    .all();

  res.json({ stats: s, byPlan, recent, month: { year, month } });
});

/* ------------------------------------------------------------------ */
/* Monthly rate declaration — the core action                          */
/* ------------------------------------------------------------------ */

// Preview what a rate would cost before committing it.
router.post('/rates/preview', (req, res) => {
  const planId = Number(req.body.plan_id);
  const rate = Number(req.body.rate);
  const year = Number(req.body.year);
  const month = Number(req.body.month);
  if (!planId || !Number.isFinite(rate) || !year || !month)
    return res.status(400).json({ error: 'Pick a plan, month and rate.' });

  const cutoff = `${year}-${String(month).padStart(2, '0')}-31`;
  const rows = db
    .prepare(
      `SELECT i.id, i.amount, i.ref_no, u.name
       FROM investments i JOIN users u ON u.id=i.user_id
       WHERE i.plan_id=? AND i.status='active' AND i.start_date IS NOT NULL AND i.start_date <= ?`
    )
    .all(planId, cutoff);

  const existing = db.prepare('SELECT id, rate FROM monthly_rates WHERE plan_id=? AND year=? AND month=?').get(planId, year, month);
  const total = rows.reduce((a, r) => a + (r.amount * rate) / 100, 0);

  res.json({
    books: rows.length,
    principal: rows.reduce((a, r) => a + r.amount, 0),
    total_payout: Number(total.toFixed(2)),
    already_declared: existing ? existing.rate : null,
    sample: rows.slice(0, 5).map((r) => ({
      name: r.name, ref_no: r.ref_no, principal: r.amount,
      credit: Number(((r.amount * rate) / 100).toFixed(2)),
    })),
  });
});

// Declare (or re-declare) the rate. Credits every eligible active book.
router.post('/rates/declare', (req, res) => {
  const planId = Number(req.body.plan_id);
  const rate = Number(req.body.rate);
  const year = Number(req.body.year);
  const month = Number(req.body.month);
  const note = String(req.body.note || '').slice(0, 300);

  const plan = db.prepare('SELECT * FROM plans WHERE id=?').get(planId);
  if (!plan) return res.status(400).json({ error: 'Plan not found.' });
  if (!Number.isFinite(rate) || rate < 0 || rate > 100)
    return res.status(400).json({ error: 'Rate must be between 0 and 100.' });
  if (month < 1 || month > 12) return res.status(400).json({ error: 'Month must be 1–12.' });
  if (year < 2000 || year > 2100) return res.status(400).json({ error: 'Check the year.' });

  const run = db.transaction(() => {
    // Upsert the declaration
    db.prepare(
      `INSERT INTO monthly_rates(plan_id,year,month,rate,note,declared_by)
       VALUES(?,?,?,?,?,?)
       ON CONFLICT(plan_id,year,month)
       DO UPDATE SET rate=excluded.rate, note=excluded.note,
                     declared_by=excluded.declared_by, declared_at=datetime('now')`
    ).run(planId, year, month, rate, note, req.user.id);

    const rateRow = db.prepare('SELECT id FROM monthly_rates WHERE plan_id=? AND year=? AND month=?').get(planId, year, month);

    // Re-declaring replaces the previous credits for that month.
    db.prepare('DELETE FROM payouts WHERE rate_id=?').run(rateRow.id);

    const cutoff = `${year}-${String(month).padStart(2, '0')}-31`;
    const books = db
      .prepare(
        `SELECT id, user_id, amount FROM investments
         WHERE plan_id=? AND status='active' AND start_date IS NOT NULL AND start_date <= ?`
      )
      .all(planId, cutoff);

    const ins = db.prepare(
      `INSERT INTO payouts(rate_id,investment_id,user_id,year,month,principal,rate,amount)
       VALUES(?,?,?,?,?,?,?,?)`
    );
    let total = 0;
    for (const b of books) {
      const amt = Number(((b.amount * rate) / 100).toFixed(2));
      ins.run(rateRow.id, b.id, b.user_id, year, month, b.amount, rate, amt);
      total += amt;
    }
    return { books: books.length, total: Number(total.toFixed(2)) };
  });

  const result = run();
  audit(req.user.id, 'rate_declared', { plan: plan.code, year, month, rate, ...result });
  res.json({
    ok: true,
    ...result,
    message: `${plan.name}: ${rate}% posted for ${month}/${year} across ${result.books} book${result.books === 1 ? '' : 's'}.`,
  });
});

// Declare the same rate across several plans at once.
router.post('/rates/declare-bulk', (req, res) => {
  const entries = Array.isArray(req.body.entries) ? req.body.entries : [];
  const year = Number(req.body.year);
  const month = Number(req.body.month);
  if (!entries.length) return res.status(400).json({ error: 'Nothing to post.' });

  const results = [];
  for (const e of entries) {
    const plan = db.prepare('SELECT * FROM plans WHERE id=?').get(Number(e.plan_id));
    const rate = Number(e.rate);
    if (!plan || !Number.isFinite(rate) || rate < 0 || rate > 100) continue;

    const run = db.transaction(() => {
      db.prepare(
        `INSERT INTO monthly_rates(plan_id,year,month,rate,note,declared_by)
         VALUES(?,?,?,?,?,?)
         ON CONFLICT(plan_id,year,month)
         DO UPDATE SET rate=excluded.rate, declared_by=excluded.declared_by, declared_at=datetime('now')`
      ).run(plan.id, year, month, rate, String(e.note || '').slice(0, 300), req.user.id);

      const rateRow = db.prepare('SELECT id FROM monthly_rates WHERE plan_id=? AND year=? AND month=?').get(plan.id, year, month);
      db.prepare('DELETE FROM payouts WHERE rate_id=?').run(rateRow.id);

      const cutoff = `${year}-${String(month).padStart(2, '0')}-31`;
      const books = db
        .prepare(`SELECT id,user_id,amount FROM investments WHERE plan_id=? AND status='active' AND start_date<=?`)
        .all(plan.id, cutoff);
      const ins = db.prepare(
        `INSERT INTO payouts(rate_id,investment_id,user_id,year,month,principal,rate,amount) VALUES(?,?,?,?,?,?,?,?)`
      );
      let total = 0;
      for (const b of books) {
        const amt = Number(((b.amount * rate) / 100).toFixed(2));
        ins.run(rateRow.id, b.id, b.user_id, year, month, b.amount, rate, amt);
        total += amt;
      }
      return { books: books.length, total: Number(total.toFixed(2)) };
    });

    const r = run();
    results.push({ plan: plan.name, rate, ...r });
  }

  audit(req.user.id, 'rate_declared_bulk', { year, month, results });
  res.json({ ok: true, results });
});

router.get('/rates', (req, res) => {
  const rows = db
    .prepare(
      `SELECT r.*, p.name plan_name, p.code plan_code, u.name declared_by_name,
              (SELECT COUNT(*) FROM payouts WHERE rate_id=r.id) books,
              (SELECT IFNULL(SUM(amount),0) FROM payouts WHERE rate_id=r.id) total
       FROM monthly_rates r JOIN plans p ON p.id=r.plan_id
       LEFT JOIN users u ON u.id=r.declared_by
       ORDER BY r.year DESC, r.month DESC, p.sort_order`
    )
    .all();
  res.json({ rates: rows });
});

router.delete('/rates/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM monthly_rates WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Declaration not found.' });
  db.prepare('DELETE FROM monthly_rates WHERE id=?').run(row.id); // payouts cascade
  audit(req.user.id, 'rate_deleted', row);
  res.json({ ok: true });
});

/* ------------------------------------------------------------------ */
/* Requests: purchases, top-ups, upgrades                              */
/* ------------------------------------------------------------------ */

router.get('/requests', (req, res) => {
  const status = req.query.status || 'pending';
  const rows = db
    .prepare(
      `SELECT t.*, u.name, u.email, u.phone, i.ref_no, i.amount AS current_amount,
              p.name AS plan_name, p.id AS plan_id
       FROM transactions t
       JOIN users u ON u.id=t.user_id
       LEFT JOIN investments i ON i.id=t.investment_id
       LEFT JOIN plans p ON p.id=i.plan_id
       WHERE t.status=? ORDER BY t.created_at DESC LIMIT 200`
    )
    .all(status);
  res.json({ requests: rows });
});

router.post('/requests/:id/approve', (req, res) => {
  const tx = db.prepare(`SELECT * FROM transactions WHERE id=? AND status='pending'`).get(req.params.id);
  if (!tx) return res.status(404).json({ error: 'Nothing pending with that reference.' });
  const inv = db.prepare('SELECT * FROM investments WHERE id=?').get(tx.investment_id);
  if (!inv) return res.status(400).json({ error: 'Linked book is missing.' });

  const startDate = String(req.body.start_date || '').match(/^\d{4}-\d{2}-\d{2}$/)
    ? req.body.start_date
    : new Date().toISOString().slice(0, 10);

  const run = db.transaction(() => {
    if (tx.type === 'purchase') {
      const plan = db.prepare('SELECT * FROM plans WHERE id=?').get(inv.plan_id);
      db.prepare(
        `UPDATE investments SET status='active', start_date=?, maturity_date=? WHERE id=?`
      ).run(startDate, addMonths(startDate, plan.tenure_months), inv.id);
    } else if (tx.type === 'topup') {
      db.prepare('UPDATE investments SET amount=amount+? WHERE id=?').run(tx.amount, inv.id);
    } else if (tx.type === 'upgrade') {
      let meta = {};
      try { meta = JSON.parse(tx.meta || '{}'); } catch { /* older rows may hold plain text */ }
      if (meta.to_plan_id) {
        const target = db.prepare('SELECT * FROM plans WHERE id=?').get(meta.to_plan_id);
        db.prepare('UPDATE investments SET plan_id=?, amount=amount+?, maturity_date=? WHERE id=?')
          .run(target.id, tx.amount, addMonths(inv.start_date || startDate, target.tenure_months), inv.id);
      }
    }
    db.prepare(`UPDATE transactions SET status='approved', settled_at=datetime('now') WHERE id=?`).run(tx.id);
  });

  run();
  audit(req.user.id, 'request_approved', { tx: tx.id, type: tx.type, amount: tx.amount });
  res.json({ ok: true });
});

router.post('/requests/:id/reject', (req, res) => {
  const tx = db.prepare(`SELECT * FROM transactions WHERE id=? AND status='pending'`).get(req.params.id);
  if (!tx) return res.status(404).json({ error: 'Nothing pending with that reference.' });
  const reason = String(req.body.reason || 'Rejected by staff').slice(0, 300);

  db.prepare(`UPDATE transactions SET status='rejected', meta=?, settled_at=datetime('now') WHERE id=?`).run(reason, tx.id);
  if (tx.type === 'purchase')
    db.prepare(`UPDATE investments SET status='rejected' WHERE id=? AND status='pending'`).run(tx.investment_id);

  audit(req.user.id, 'request_rejected', { tx: tx.id, reason });
  res.json({ ok: true });
});

/* ------------------------------------------------------------------ */
/* Customers & books                                                   */
/* ------------------------------------------------------------------ */

router.get('/customers', (req, res) => {
  const q = `%${String(req.query.q || '').trim()}%`;
  const rows = db
    .prepare(
      `SELECT u.id,u.name,u.email,u.phone,u.status,u.kyc_status,u.created_at,
              (SELECT COUNT(*) FROM investments WHERE user_id=u.id AND status='active') books,
              (SELECT IFNULL(SUM(amount),0) FROM investments WHERE user_id=u.id AND status='active') principal,
              (SELECT IFNULL(SUM(amount),0) FROM payouts WHERE user_id=u.id) returned
       FROM users u
       WHERE u.role='customer' AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)
       ORDER BY u.created_at DESC LIMIT 300`
    )
    .all(q, q, q);
  res.json({ customers: rows });
});

router.get('/customers/:id', (req, res) => {
  const user = db
    .prepare(`SELECT id,name,email,phone,status,kyc_status,created_at FROM users WHERE id=? AND role='customer'`)
    .get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Customer not found.' });

  const investments = db
    .prepare(
      `SELECT i.*, p.name plan_name, p.code plan_code,
              (SELECT IFNULL(SUM(amount),0) FROM payouts WHERE investment_id=i.id) returned
       FROM investments i JOIN plans p ON p.id=i.plan_id
       WHERE i.user_id=? ORDER BY i.created_at DESC`
    )
    .all(user.id);

  const transactions = db
    .prepare(`SELECT t.*, i.ref_no FROM transactions t LEFT JOIN investments i ON i.id=t.investment_id
              WHERE t.user_id=? ORDER BY t.created_at DESC LIMIT 100`)
    .all(user.id);

  const payouts = db
    .prepare(`SELECT p.*, i.ref_no FROM payouts p JOIN investments i ON i.id=p.investment_id
              WHERE p.user_id=? ORDER BY p.year DESC, p.month DESC LIMIT 100`)
    .all(user.id);

  res.json({ user, investments, transactions, payouts });
});

router.patch('/customers/:id', (req, res) => {
  const fields = [];
  const vals = [];
  if (['active', 'blocked'].includes(req.body.status)) { fields.push('status=?'); vals.push(req.body.status); }
  if (['pending', 'verified', 'rejected'].includes(req.body.kyc_status)) { fields.push('kyc_status=?'); vals.push(req.body.kyc_status); }
  if (req.body.name) { fields.push('name=?'); vals.push(String(req.body.name).trim()); }
  if (req.body.phone) { fields.push('phone=?'); vals.push(String(req.body.phone).trim()); }
  if (!fields.length) return res.status(400).json({ error: 'Nothing to change.' });

  vals.push(req.params.id);
  db.prepare(`UPDATE users SET ${fields.join(', ')} WHERE id=? AND role='customer'`).run(...vals);
  audit(req.user.id, 'customer_updated', { id: req.params.id, body: req.body });
  res.json({ ok: true });
});

router.post('/customers/:id/reset-password', (req, res) => {
  const pw = String(req.body.password || '');
  if (pw.length < 8) return res.status(400).json({ error: 'Password needs at least 8 characters.' });
  db.prepare(`UPDATE users SET password_hash=? WHERE id=? AND role='customer'`).run(bcrypt.hashSync(pw, 10), req.params.id);
  audit(req.user.id, 'password_reset', { id: req.params.id });
  res.json({ ok: true });
});

router.get('/investments', (req, res) => {
  const status = req.query.status;
  const where = status && status !== 'all' ? 'WHERE i.status=?' : '';
  const stmt = db.prepare(
    `SELECT i.*, u.name, u.email, u.phone, p.name plan_name, p.code plan_code,
            (SELECT IFNULL(SUM(amount),0) FROM payouts WHERE investment_id=i.id) returned
     FROM investments i JOIN users u ON u.id=i.user_id JOIN plans p ON p.id=i.plan_id
     ${where} ORDER BY i.created_at DESC LIMIT 300`
  );
  res.json({ investments: status && status !== 'all' ? stmt.all(status) : stmt.all() });
});

router.patch('/investments/:id', (req, res) => {
  const inv = db.prepare('SELECT * FROM investments WHERE id=?').get(req.params.id);
  if (!inv) return res.status(404).json({ error: 'Book not found.' });

  const fields = [];
  const vals = [];
  if (['pending', 'active', 'matured', 'closed', 'rejected'].includes(req.body.status)) {
    fields.push('status=?'); vals.push(req.body.status);
    if (req.body.status === 'active' && !inv.start_date) {
      fields.push("start_date=date('now')");
    }
  }
  if (req.body.amount !== undefined) { fields.push('amount=?'); vals.push(money(req.body.amount)); }
  if (req.body.start_date) { fields.push('start_date=?'); vals.push(req.body.start_date); }
  if (req.body.plan_id) { fields.push('plan_id=?'); vals.push(Number(req.body.plan_id)); }
  if (req.body.note !== undefined) { fields.push('note=?'); vals.push(String(req.body.note).slice(0, 300)); }
  if (!fields.length) return res.status(400).json({ error: 'Nothing to change.' });

  vals.push(inv.id);
  db.prepare(`UPDATE investments SET ${fields.join(', ')} WHERE id=?`).run(...vals);
  audit(req.user.id, 'investment_updated', { id: inv.id, body: req.body });
  res.json({ ok: true });
});

// Open a book on a customer's behalf (walk-in at the counter)
router.post('/investments', (req, res) => {
  const userId = Number(req.body.user_id);
  const planId = Number(req.body.plan_id);
  const amount = money(req.body.amount);
  const user = db.prepare(`SELECT * FROM users WHERE id=? AND role='customer'`).get(userId);
  const plan = db.prepare('SELECT * FROM plans WHERE id=?').get(planId);
  if (!user) return res.status(400).json({ error: 'Customer not found.' });
  if (!plan) return res.status(400).json({ error: 'Plan not found.' });
  if (amount < plan.min_amount || amount > plan.max_amount)
    return res.status(400).json({
      error: `${plan.name} takes ₹${plan.min_amount.toLocaleString('en-IN')} – ₹${plan.max_amount.toLocaleString('en-IN')}.`,
    });

  const startDate = String(req.body.start_date || '').match(/^\d{4}-\d{2}-\d{2}$/)
    ? req.body.start_date : new Date().toISOString().slice(0, 10);
  const ref = 'TRG-' + Date.now().toString(36).toUpperCase().slice(-6) + '-' + userId;

  const info = db
    .prepare(`INSERT INTO investments(user_id,plan_id,amount,status,ref_no,start_date,maturity_date,note)
              VALUES(?,?,?,'active',?,?,?,?)`)
    .run(userId, planId, amount, ref, startDate, addMonths(startDate, plan.tenure_months), String(req.body.note || 'Opened at counter'));

  db.prepare(`INSERT INTO transactions(user_id,investment_id,type,amount,status,meta,settled_at)
              VALUES(?,?,'purchase',?,'approved','Opened at counter',datetime('now'))`)
    .run(userId, info.lastInsertRowid, amount);

  audit(req.user.id, 'investment_created', { user: userId, plan: plan.code, amount, ref });
  res.json({ ok: true, ref_no: ref });
});

/* ------------------------------------------------------------------ */
/* Plans                                                               */
/* ------------------------------------------------------------------ */

router.get('/plans', (req, res) => {
  const plans = db.prepare('SELECT * FROM plans ORDER BY sort_order, min_amount').all();
  for (const p of plans) {
    const agg = db.prepare(`SELECT COUNT(*) c, IFNULL(SUM(amount),0) s FROM investments WHERE plan_id=? AND status='active'`).get(p.id);
    p.active_books = agg.c;
    p.principal = agg.s;
  }
  res.json({ plans });
});

const planFields = ['code','name','tagline','min_amount','max_amount','indicative_rate','tenure_months','lockin_months','perks','sort_order','is_active'];

router.post('/plans', (req, res) => {
  const b = req.body;
  if (!b.code || !b.name) return res.status(400).json({ error: 'Give the plan a code and a name.' });
  if (money(b.min_amount) >= money(b.max_amount))
    return res.status(400).json({ error: 'Maximum must be above minimum.' });
  try {
    const info = db
      .prepare(`INSERT INTO plans(code,name,tagline,min_amount,max_amount,indicative_rate,tenure_months,lockin_months,perks,sort_order,is_active)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
      .run(
        String(b.code).toUpperCase().trim(), String(b.name).trim(), String(b.tagline || ''),
        money(b.min_amount), money(b.max_amount), Number(b.indicative_rate) || 0,
        Number(b.tenure_months) || 12, Number(b.lockin_months) || 0,
        String(b.perks || ''), Number(b.sort_order) || 0, b.is_active === false ? 0 : 1
      );
    audit(req.user.id, 'plan_created', { id: info.lastInsertRowid, code: b.code });
    res.json({ ok: true, id: info.lastInsertRowid });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return res.status(409).json({ error: 'That plan code is already used.' });
    throw e;
  }
});

router.patch('/plans/:id', (req, res) => {
  const plan = db.prepare('SELECT * FROM plans WHERE id=?').get(req.params.id);
  if (!plan) return res.status(404).json({ error: 'Plan not found.' });

  const sets = [];
  const vals = [];
  for (const f of planFields) {
    if (req.body[f] === undefined) continue;
    let v = req.body[f];
    if (['min_amount','max_amount','tenure_months','lockin_months','sort_order'].includes(f)) v = money(v);
    if (f === 'indicative_rate') v = Number(v) || 0;
    if (f === 'is_active') v = v ? 1 : 0;
    if (f === 'code') v = String(v).toUpperCase().trim();
    sets.push(`${f}=?`); vals.push(v);
  }
  if (!sets.length) return res.status(400).json({ error: 'Nothing to change.' });
  vals.push(plan.id);
  db.prepare(`UPDATE plans SET ${sets.join(', ')} WHERE id=?`).run(...vals);
  audit(req.user.id, 'plan_updated', { id: plan.id, body: req.body });
  res.json({ ok: true });
});

router.delete('/plans/:id', (req, res) => {
  const inUse = db.prepare(`SELECT COUNT(*) c FROM investments WHERE plan_id=?`).get(req.params.id).c;
  if (inUse) {
    db.prepare('UPDATE plans SET is_active=0 WHERE id=?').run(req.params.id);
    return res.json({ ok: true, message: 'Books exist on this plan, so it was closed to new customers instead of deleted.' });
  }
  db.prepare('DELETE FROM plans WHERE id=?').run(req.params.id);
  audit(req.user.id, 'plan_deleted', { id: req.params.id });
  res.json({ ok: true });
});

/* ------------------------------------------------------------------ */
/* Settings & audit                                                    */
/* ------------------------------------------------------------------ */

router.get('/settings', (req, res) => {
  const rows = db.prepare('SELECT key,value FROM settings').all();
  res.json({ settings: Object.fromEntries(rows.map((r) => [r.key, r.value])) });
});

router.put('/settings', (req, res) => {
  const allowed = [
    'shop_name','shop_tagline','shop_phone','shop_email','shop_address','shop_whatsapp',
    'bank_name','bank_account','bank_ifsc','upi_id','gold_rate_916','disclaimer',
  ];
  for (const k of allowed) if (req.body[k] !== undefined) setSetting(k, String(req.body[k]));
  audit(req.user.id, 'settings_updated', Object.keys(req.body));
  res.json({ ok: true });
});

router.get('/audit', (req, res) => {
  const rows = db
    .prepare(`SELECT a.*, u.name actor FROM audit_log a LEFT JOIN users u ON u.id=a.actor_id
              ORDER BY a.created_at DESC LIMIT 200`)
    .all();
  res.json({ log: rows });
});

// CSV export of the payout ledger
router.get('/export/payouts.csv', (req, res) => {
  const rows = db
    .prepare(`SELECT p.year,p.month,u.name,u.email,i.ref_no,pl.name plan,p.principal,p.rate,p.amount,p.created_at
              FROM payouts p JOIN users u ON u.id=p.user_id JOIN investments i ON i.id=p.investment_id
              JOIN plans pl ON pl.id=i.plan_id ORDER BY p.year DESC,p.month DESC`)
    .all();
  const head = 'Year,Month,Customer,Email,Ref,Plan,Principal,Rate %,Credited,Posted On';
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const body = rows.map((r) => [r.year,r.month,r.name,r.email,r.ref_no,r.plan,r.principal,r.rate,r.amount,r.created_at].map(esc).join(','));
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="truereturn-payouts.csv"');
  res.send([head, ...body].join('\n'));
});

module.exports = router;
