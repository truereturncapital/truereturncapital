# TrueReturn Gold

Investment-plan management for a jewellery shop: a public rate board, customer
passbooks, and an admin panel that declares one rate per plan per month.

The idea the whole system is built around: **the shop declares a rate, and that
same number appears in three places at once** — the public landing page, every
customer's dashboard, and the payout ledger. There is no second set of books.

---

## Run it

```bash
npm install
cp .env.example .env      # then edit .env — see below
npm run seed              # creates admin, 4 plans, a demo customer
npm start
```

Open `http://localhost:3000`.

| | |
|---|---|
| Landing page | `http://localhost:3000/` |
| Customer dashboard | `http://localhost:3000/dashboard` |
| Admin panel | `http://localhost:3000/admin` |

**Seeded logins** (change these immediately):

| Role | Email | Password |
|---|---|---|
| Admin | `admin@truereturngold.com` | `Admin@12345` |
| Demo customer | `demo@truereturngold.com` | `Demo@12345` |

Requires Node 18+. Data lives in `data/truereturn.db` (SQLite) — back up that
one file and you have backed up everything.

---

## .env

```
PORT=3000
NODE_ENV=production
JWT_SECRET=<long random string — change this>
ADMIN_EMAIL=admin@yourshop.com
ADMIN_PASSWORD=<strong password>
SEED_DEMO=false          # skip the demo customer on a real install
```

Generate a secret:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

If `JWT_SECRET` stays at the default, anyone who reads this repo can forge an
admin session. Change it before the site is reachable from the internet.

---

## The monthly cycle

This is the routine the shop runs every month.

1. **Admin panel → Declare the month.** Pick the month, type a percentage next
   to each plan.
2. **Select "Work out the cost first."** This shows exactly how many rupees the
   declaration will commit, per plan and in total, *before* anything is written.
3. **Select "Post these rates."** In one transaction the system writes a credit
   line into every open book on that plan, and publishes the rate to the public
   board.

Re-posting a month you have already declared **replaces** the earlier credits
for that month rather than adding to them — so correcting a typo is safe. "Undo"
in Rate history removes a declaration and every credit it created.

Only books whose start date falls on or before the declared month are credited.
A book opened in September will not be credited for August.

### How a credit is calculated

```
credit = principal × rate ÷ 100
```

Every row in a customer's passbook shows all three numbers, so the customer can
check the arithmetic themselves. That is deliberate — it is the cheapest way to
prevent disputes.

---

## Customer flow

1. Sign up (no payment at this step).
2. Pick a book, name an amount → creates a **pending request** with a reference
   number. Nothing is active yet.
3. Customer pays at the counter or by transfer, quoting the reference.
4. Admin → Requests → **Confirm payment**. The book opens from the date you set
   (you can backdate it).

Top-ups and upgrades follow the same request-then-confirm path. Money never
moves inside this app — it only records what the shop confirms.

**Upgrade** moves a book to a larger plan; the customer adds the difference and
the plan, amount, and maturity date all update on approval.

---

## Admin panel

| Tab | What it does |
|---|---|
| Overview | Customers, amount held, credited to date, pending count, per-plan breakdown with this month's payout cost |
| Declare the month | The monthly rate declaration, with cost preview |
| Requests | Confirm or reject new books, top-ups, upgrades |
| Customers | Search, view full history, set KYC, block, reset password |
| Books | Every book; edit status or amount; open a book at the counter; export payout CSV |
| Plans | Add/edit/remove plans, ranges, terms, perks, visibility |
| Rate history | Every declaration, its cost, who made it, undo |
| Shop settings | Name, contact, bank/UPI details, today's 916 rate, disclosure text |

Everything on the public landing page — plan names, ranges, perks, disclosure
text, gold rate — is editable from Shop settings and Plans. You should not need
to touch the HTML to rebrand.

---

## Project layout

```
server.js              Express app, static hosting, rate limiting
db.js                  SQLite schema + connection
auth.js                JWT cookie auth, requireAuth / requireAdmin
seed.js                Admin, 4 plans, demo customer
routes/
  customer.js          Public overview, auth, dashboard, purchase/topup/upgrade
  admin.js             Stats, declaration engine, approvals, CRUD, CSV export
public/
  index.html           Landing page (rate board)
  login.html signup.html dashboard.html admin.html 404.html
  css/app.css          Design tokens, buttons, forms, tables, modals
  css/landing.css      Landing page + auth pages
  css/app-shell.css    Dashboard & admin shell, the passbook
  js/common.js         API client, ₹ formatting, toast, modal
  js/landing.js js/dashboard.js js/admin.js
data/truereturn.db     Created on first run
```

### Tables

`users` · `plans` · `investments` · `transactions` · `monthly_rates` ·
`payouts` · `settings` · `audit_log`

`monthly_rates` holds one row per plan per month (enforced by a unique
constraint). `payouts` holds one row per book per declaration, storing the
principal and rate used — so a historical credit stays correct even if the
book's principal changes later.

---

## Deploying

Any host that runs Node works — a small VPS, Railway, Render, Fly.

```bash
npm install --omit=dev
NODE_ENV=production node server.js
```

Put it behind nginx or Caddy with HTTPS. With `NODE_ENV=production` the auth
cookie is set `secure`, so **it will not work over plain HTTP** — TLS is not
optional here.

Back up `data/truereturn.db` on a schedule. A nightly copy to another machine is
enough; losing it means losing every passbook.

For a shop with more than a few thousand customers, move to Postgres. The SQL is
plain enough that the port is mostly mechanical.

---

## Before you take a single rupee

The software will happily declare whatever rate you type. That does not make the
rate lawful or sustainable, and this section is the part worth re-reading.

**2–5% a month is 24–60% a year.** Gold appreciation and jewellery retail margin
do not produce that. If the payout does not come from a real, documented source
of profit, it comes from the next customer's deposit — and a scheme that pays
old depositors from new deposits is a Ponzi scheme regardless of what it is
called or how sincerely it is run. It collapses when intake slows, which it
always eventually does, and the people holding books at that moment lose
everything.

Work out the arithmetic before launch, not after: at 3% monthly on ₹1 crore held,
the shop owes ₹3 lakh *every month*, forever, on top of returning the principal.
Ask where that comes from and write the answer down.

**Indian law that applies:**

- **Banning of Unregulated Deposit Schemes Act, 2019 (BUDS Act)** — accepting
  deposits from the public outside a registered, regulated scheme is a criminal
  offence, with imprisonment and attachment of assets. This is the main one.
- **Companies (Acceptance of Deposits) Rules, 2014** — governs jeweller savings
  schemes. Typical constraints: maximum 12 months, and no promise of guaranteed
  interest.
- **Prize Chits and Money Circulation Schemes (Banning) Act, 1978.**
- **Chit Funds Act, 1982**, if the structure is closer to a chitty.

A conventional jeweller's gold savings scheme — customer pays monthly
instalments, shop adds a bonus instalment at the end, redeemable against
jewellery — generally fits inside these rules. A scheme paying a monthly cash
percentage on a lump-sum deposit generally does not.

**Do this first:** sit with a company secretary or a lawyer who handles deposit
regulation. Get, in writing, which registration your scheme runs under. Then put
that registration number into Shop settings → Disclosure text so it appears on
the landing page. If nobody will put that in writing, treat it as the answer.

What is already built in to help:

- Rates are described as **declared, not guaranteed**, everywhere in the UI.
- The landing page carries a disclosure section and an editable disclaimer.
- The admin panel shows the rupee cost of a declaration before you commit it.
- Every credit shows its own arithmetic, so customers can audit their passbook.
- `audit_log` records who declared what and when.

These reduce disputes and make the shop's own exposure visible. They are not a
substitute for being registered.

---

## Licence

Yours to use and modify.
