const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, 'truereturn.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  phone         TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'customer',   -- customer | admin
  status        TEXT NOT NULL DEFAULT 'active',     -- active | blocked
  kyc_status    TEXT NOT NULL DEFAULT 'pending',    -- pending | verified | rejected
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS plans (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  code          TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  tagline       TEXT,
  min_amount    INTEGER NOT NULL,
  max_amount    INTEGER NOT NULL,
  indicative_rate REAL NOT NULL DEFAULT 0,          -- shown as "indicative", not guaranteed
  tenure_months INTEGER NOT NULL DEFAULT 12,
  lockin_months INTEGER NOT NULL DEFAULT 0,
  perks         TEXT,                               -- newline separated
  sort_order    INTEGER NOT NULL DEFAULT 0,
  is_active     INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS investments (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id       INTEGER NOT NULL REFERENCES plans(id),
  amount        INTEGER NOT NULL,                   -- current principal (after top-ups)
  status        TEXT NOT NULL DEFAULT 'pending',    -- pending | active | matured | closed | rejected
  ref_no        TEXT NOT NULL UNIQUE,
  start_date    TEXT,
  maturity_date TEXT,
  note          TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Every money movement. Ledger is append-only in spirit.
CREATE TABLE IF NOT EXISTS transactions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  investment_id INTEGER REFERENCES investments(id) ON DELETE CASCADE,
  type          TEXT NOT NULL,                      -- purchase | topup | upgrade | return | withdrawal | adjustment
  amount        INTEGER NOT NULL,
  status        TEXT NOT NULL DEFAULT 'pending',    -- pending | approved | rejected
  meta          TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  settled_at    TEXT
);

-- Admin declares one rate per plan per month. This drives everything.
CREATE TABLE IF NOT EXISTS monthly_rates (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  plan_id       INTEGER NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
  year          INTEGER NOT NULL,
  month         INTEGER NOT NULL,                   -- 1-12
  rate          REAL NOT NULL,                      -- percent for that month
  note          TEXT,
  declared_by   INTEGER REFERENCES users(id),
  declared_at   TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(plan_id, year, month)
);

-- One row per investment per declared month.
CREATE TABLE IF NOT EXISTS payouts (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  rate_id       INTEGER NOT NULL REFERENCES monthly_rates(id) ON DELETE CASCADE,
  investment_id INTEGER NOT NULL REFERENCES investments(id) ON DELETE CASCADE,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  year          INTEGER NOT NULL,
  month         INTEGER NOT NULL,
  principal     INTEGER NOT NULL,
  rate          REAL NOT NULL,
  amount        REAL NOT NULL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(rate_id, investment_id)
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_id   INTEGER REFERENCES users(id),
  action     TEXT NOT NULL,
  detail     TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_inv_user   ON investments(user_id);
CREATE INDEX IF NOT EXISTS idx_inv_status ON investments(status);
CREATE INDEX IF NOT EXISTS idx_tx_user    ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_tx_status  ON transactions(status);
CREATE INDEX IF NOT EXISTS idx_pay_user   ON payouts(user_id);
CREATE INDEX IF NOT EXISTS idx_pay_inv    ON payouts(investment_id);
CREATE INDEX IF NOT EXISTS idx_rate_plan  ON monthly_rates(plan_id, year, month);
`);

function setSetting(key, value) {
  db.prepare(`INSERT INTO settings(key,value) VALUES(?,?)
              ON CONFLICT(key) DO UPDATE SET value=excluded.value`).run(key, String(value));
}
function getSetting(key, fallback = null) {
  const r = db.prepare(`SELECT value FROM settings WHERE key=?`).get(key);
  return r ? r.value : fallback;
}
function audit(actorId, action, detail) {
  db.prepare(`INSERT INTO audit_log(actor_id,action,detail) VALUES(?,?,?)`)
    .run(actorId || null, action, typeof detail === 'string' ? detail : JSON.stringify(detail || {}));
}

module.exports = { db, setSetting, getSetting, audit, DATA_DIR };
