const jwt = require('jsonwebtoken');
const { db } = require('./db');

const SECRET = process.env.JWT_SECRET || 'change-this-secret-in-production-please';
const MAX_AGE = 7 * 24 * 60 * 60 * 1000;

function sign(user) {
  return jwt.sign({ id: user.id, role: user.role }, SECRET, { expiresIn: '7d' });
}

function setAuthCookie(res, user) {
  res.cookie('trg_token', sign(user), {
    httpOnly: true,
    sameSite: 'lax',
    maxAge: MAX_AGE,
    secure: process.env.NODE_ENV === 'production',
  });
}

function clearAuthCookie(res) {
  res.clearCookie('trg_token');
}

// Attaches req.user when a valid token is present. Never throws.
function attachUser(req, _res, next) {
  const token =
    req.cookies?.trg_token ||
    (req.headers.authorization?.startsWith('Bearer ')
      ? req.headers.authorization.slice(7)
      : null);
  if (token) {
    try {
      const payload = jwt.verify(token, SECRET);
      const user = db
        .prepare(
          'SELECT id,name,email,phone,role,status,kyc_status,created_at FROM users WHERE id=?'
        )
        .get(payload.id);
      if (user && user.status === 'active') req.user = user;
    } catch {
      /* invalid or expired token — treat as signed out */
    }
  }
  next();
}

function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Sign in to continue.' });
  next();
}

function requireAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Sign in to continue.' });
  if (req.user.role !== 'admin')
    return res.status(403).json({ error: 'This area is for staff accounts.' });
  next();
}

module.exports = { sign, setAuthCookie, clearAuthCookie, attachUser, requireAuth, requireAdmin, SECRET };
